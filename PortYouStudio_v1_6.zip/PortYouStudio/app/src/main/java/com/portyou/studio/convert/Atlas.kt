package com.portyou.studio.convert

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Kotlin port of tools/portyou/atlas.py: Adobe Animate spritemap reader + Sparrow packer. */
object Atlas {
    const val MAX_SHEET = 2048

    fun loadJson(f: File): JSONObject = JSONObject(f.readText().removePrefix("\uFEFF"))

    /** Stripped atlases are 1x1 / fully transparent images (the real art lives in the base game). */
    fun isPlaceholder(png: File): Boolean {
        if (!png.isFile) return true
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(png.path, o)
        if (o.outWidth <= 4 && o.outHeight <= 4) return true
        val bmp = BitmapFactory.decodeFile(png.path) ?: return true
        try {
            val row = IntArray(bmp.width)
            for (y in 0 until bmp.height) {
                bmp.getPixels(row, 0, bmp.width, 0, y, bmp.width, 1)
                for (p in row) if ((p ushr 24) != 0) return false
            }
            return true
        } finally { bmp.recycle() }
    }

    /** Cheap check (no sprite decoding): is any spritemap image of this atlas folder a stripped placeholder? */
    fun atlasIsPlaceholder(folder: File): Boolean {
        val metas = folder.listFiles { f -> f.name.startsWith("spritemap") && f.name.endsWith(".json") } ?: return true
        for (jf in metas) {
            val imgName = try { loadJson(jf).optJSONObject("meta")?.optString("image", "").orEmpty() } catch (e: Exception) { "" }
            var png = File(folder, imgName)
            if (imgName.isEmpty() || !png.isFile) png = File(jf.path.removeSuffix(".json") + ".png")
            if (isPlaceholder(png)) return true
        }
        return false
    }

    /** (a, b, c, d, tx, ty) */
    class Mx(val a: Double, val b: Double, val c: Double, val d: Double, val tx: Double, val ty: Double) {
        /** parent o child */
        fun mul(o: Mx) = Mx(a * o.a + c * o.b, b * o.a + d * o.b, a * o.c + c * o.d, b * o.c + d * o.d, a * o.tx + c * o.ty + tx, b * o.tx + d * o.ty + ty)
        companion object { val ID = Mx(1.0, 0.0, 0.0, 1.0, 0.0, 0.0) }
    }

    fun mxOf(el: JSONObject): Mx {
        el.optJSONArray("MX")?.let { if (it.length() >= 6) return Mx(it.getDouble(0), it.getDouble(1), it.getDouble(2), it.getDouble(3), it.getDouble(4), it.getDouble(5)) }
        el.optJSONArray("M3D")?.let { if (it.length() >= 14) return Mx(it.getDouble(0), it.getDouble(1), it.getDouble(4), it.getDouble(5), it.getDouble(12), it.getDouble(13)) }
        return Mx.ID
    }

    class Frames(val frames: List<Bitmap>, val originX: Int, val originY: Int, val scale: Double)
    class Group(val prefix: String, val frames: List<Bitmap>)

    private class Quad(val name: String, val m: Mx)
    private class Label(val name: String, val start: Int, val dur: Int)

    class SpriteMapReader(private val folder: File) {
        private val symbols = HashMap<String, JSONObject>()
        private val main: JSONObject
        val sprites = HashMap<String, Bitmap>()
        var placeholder = false; private set

        init {
            val anim = loadJson(File(folder, "Animation.json"))
            anim.optJSONObject("SD")?.optJSONArray("S")?.let { arr ->
                for (i in 0 until arr.length()) { val s = arr.getJSONObject(i); symbols[s.getString("SN")] = s.getJSONObject("TL") }
            }
            main = anim.getJSONObject("AN").getJSONObject("TL")
            val metas = folder.listFiles { f -> f.name.startsWith("spritemap") && f.name.endsWith(".json") }?.sortedBy { it.name } ?: emptyList()
            for (jf in metas) {
                val meta = loadJson(jf)
                val imgName = meta.optJSONObject("meta")?.optString("image", "").orEmpty()
                var png = File(folder, imgName)
                if (imgName.isEmpty() || !png.isFile) png = File(jf.path.removeSuffix(".json") + ".png")
                if (isPlaceholder(png)) { placeholder = true; continue }
                val sheet = BitmapFactory.decodeFile(png.path) ?: continue
                val arr = meta.getJSONObject("ATLAS").getJSONArray("SPRITES")
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i).getJSONObject("SPRITE")
                    val rot = s.optBoolean("rotated", false)
                    val x = s.getInt("x"); val y = s.getInt("y")
                    val w = if (rot) s.getInt("h") else s.getInt("w"); val h = if (rot) s.getInt("w") else s.getInt("h")
                    val cw = min(w, sheet.width - x); val ch = min(h, sheet.height - y)
                    if (cw <= 0 || ch <= 0) continue
                    var im = Bitmap.createBitmap(sheet, x, y, cw, ch)
                    if (rot) { val r = Bitmap.createBitmap(im, 0, 0, im.width, im.height, Matrix().apply { postRotate(-90f) }, true); if (r !== im) im.recycle(); im = r }
                    sprites[s.getString("name")] = im
                }
                sheet.recycle()
            }
        }

        /** labels of the main timeline (layer holding frame names) */
        private fun labels(): LinkedHashMap<String, Label> {
            val out = LinkedHashMap<String, Label>()
            val layers = main.getJSONArray("L")
            for (l in 0 until layers.length()) {
                val fr = layers.getJSONObject(l).getJSONArray("FR")
                for (i in 0 until fr.length()) { val f = fr.getJSONObject(i); if (f.has("N")) out[f.getString("N")] = Label(f.getString("N"), f.getInt("I"), f.getInt("DU")) }
            }
            return out
        }

        /** exact -> prefix -> same words -> contains -> fuzzy -> optional hint (local AI is not used on the phone) */
        private fun findLabel(wanted: String): Label? {
            val labs = labels(); val w = wanted.lowercase()
            labs.values.firstOrNull { it.name.lowercase() == w }?.let { return it }
            labs.values.firstOrNull { it.name.lowercase().startsWith(w) }?.let { return it }
            val nw = norm(wanted)
            labs.values.firstOrNull { norm(it.name) == nw }?.let { return it }
            labs.values.firstOrNull { nw.isNotEmpty() && norm(it.name).length >= 3 && (nw in norm(it.name) || norm(it.name) in nw) }?.let { return it }
            val names = labs.values.associateBy { norm(it.name) }
            var best: String? = null; var bestR = 0.6
            for (k in names.keys) { val r = ratio(nw, k); if (r >= bestR) { bestR = r; best = k } }
            return best?.let { names[it] }
        }

        private fun norm(n: String) = n.lowercase().replace(Regex("\\d+$"), "").replace(Regex("[^a-z0-9]+"), "")

        /** difflib.SequenceMatcher.ratio() replacement: 2*LCS/(len a + len b) */
        private fun ratio(a: String, b: String): Double {
            if (a.isEmpty() && b.isEmpty()) return 1.0
            if (a.isEmpty() || b.isEmpty()) return 0.0
            var prev = IntArray(b.length + 1)
            for (i in 1..a.length) {
                val cur = IntArray(b.length + 1)
                for (j in 1..b.length) cur[j] = if (a[i - 1] == b[j - 1]) prev[j - 1] + 1 else max(prev[j], cur[j - 1])
                prev = cur
            }
            return 2.0 * prev[b.length] / (a.length + b.length)
        }

        private fun length(tl: JSONObject): Int {
            var n = 0; val layers = tl.getJSONArray("L")
            for (l in 0 until layers.length()) { val fr = layers.getJSONObject(l).getJSONArray("FR"); for (i in 0 until fr.length()) { val f = fr.getJSONObject(i); n = max(n, f.getInt("I") + f.getInt("DU")) } }
            return max(n, 1)
        }

        private fun collect(tl: JSONObject, t: Int, mat: Mx, out: MutableList<Quad>, depth: Int = 0) {
            if (depth > 24) return
            val layers = tl.getJSONArray("L")
            for (l in layers.length() - 1 downTo 0) {      // first layer is the top one
                val fr = layers.getJSONObject(l).getJSONArray("FR")
                for (i in 0 until fr.length()) {
                    val f = fr.getJSONObject(i); val fi = f.getInt("I")
                    if (t < fi || t >= fi + f.getInt("DU")) continue
                    val els = f.optJSONArray("E") ?: continue
                    for (e in 0 until els.length()) {
                        val el = els.getJSONObject(e)
                        if (el.has("ASI")) {
                            val a = el.getJSONObject("ASI")
                            out.add(Quad(if (a.has("N")) a.getString("N") else a.optInt("Index", 0).toString(), mat.mul(mxOf(a))))
                        } else if (el.has("SI")) {
                            val si = el.getJSONObject("SI")
                            val sym = symbols[si.getString("SN")] ?: continue
                            val ln = length(sym); val off = t - fi
                            val mode = si.optString("LP", "LP"); val ff = si.optInt("FF", 0)
                            val ct = when (mode) { "SF" -> ff; "PO" -> min(ff + off, ln - 1); else -> (ff + off) % ln }
                            collect(sym, ct, mat.mul(mxOf(si)), out, depth + 1)
                        }
                    }
                }
            }
        }

        private fun bbox(quads: List<Quad>): DoubleArray? {
            var x0 = Double.MAX_VALUE; var y0 = Double.MAX_VALUE; var x1 = -Double.MAX_VALUE; var y1 = -Double.MAX_VALUE; var any = false
            for (q in quads) {
                val im = sprites[q.name] ?: continue
                for ((px, py) in listOf(0 to 0, im.width to 0, 0 to im.height, im.width to im.height)) {
                    val x = q.m.a * px + q.m.c * py + q.m.tx; val y = q.m.b * px + q.m.d * py + q.m.ty
                    x0 = min(x0, x); y0 = min(y0, y); x1 = max(x1, x); y1 = max(y1, y); any = true
                }
            }
            return if (any) doubleArrayOf(x0, y0, x1, y1) else null
        }

        /** Renders every frame of a label with a SHARED origin (same maths as atlas.py). */
        fun renderLabel(name: String, scale: Double = 1.0, maxPx: Int = 2048): Frames? {
            val lab = findLabel(name) ?: return null
            val per = (0 until lab.dur).map { i -> ArrayList<Quad>().also { collect(main, lab.start + i, Mx.ID, it) } }
            val boxes = per.mapNotNull { bbox(it) }
            if (boxes.isEmpty()) return null
            val x0 = floor(boxes.minOf { it[0] }).toInt(); val y0 = floor(boxes.minOf { it[1] }).toInt()
            val x1 = ceil(boxes.maxOf { it[2] }).toInt(); val y1 = ceil(boxes.maxOf { it[3] }).toInt()
            val w = max(1, x1 - x0); val h = max(1, y1 - y0)
            val s = min(scale, maxPx.toDouble() / max(w, h))
            val cw = max(1, (w * s).roundToInt()); val ch = max(1, (h * s).roundToInt())
            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            val frames = ArrayList<Bitmap>()
            for (quads in per) {
                val canvasBmp = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888); val cv = Canvas(canvasBmp)
                for (q in quads) {
                    val im = sprites[q.name] ?: continue
                    val m = q.m
                    val a = m.a * s; val b = m.b * s; val c = m.c * s; val d = m.d * s
                    if (abs(a * d - b * c) < 1e-9) continue
                    val mat = Matrix(); mat.setValues(floatArrayOf(a.toFloat(), c.toFloat(), ((m.tx - x0) * s).toFloat(), b.toFloat(), d.toFloat(), ((m.ty - y0) * s).toFloat(), 0f, 0f, 1f))
                    cv.drawBitmap(im, mat, paint)
                }
                frames.add(canvasBmp)
            }
            return Frames(frames, x0, y0, s)
        }

        fun recycle() { sprites.values.forEach { it.recycle() }; sprites.clear() }
    }

    // ------------------------------------------------------------------ sparrow
    private class Item(val name: String, val img: Bitmap, val fx: Int, val fy: Int, val fw: Int, val fh: Int)

    /** Returns the trimmed bitmap plus the offset of the trim box inside the original canvas. */
    private fun trim(src: Bitmap): Triple<Bitmap, Int, Int> {
        val w = src.width; val h = src.height; val row = IntArray(w)
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) if ((row[x] ushr 24) != 0) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; maxY = y }
        }
        if (maxX < 0) return Triple(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888), 0, 0)
        return Triple(Bitmap.createBitmap(src, minX, minY, maxX - minX + 1, maxY - minY + 1), minX, minY)
    }

    private class Sheet { val placed = ArrayList<Triple<Int, Int, Int>>(); var w = 0; var h = 0; var x = 0; var y = 0; var rowH = 0 }

    /**
     * groups: (prefix, frames) -> Sparrow sheets + xml. Frame names are prefix + %04d; every frame keeps its canvas size (frameWidth/Height).
     * A sheet never exceeds MAX_SHEET px in height: extra frames go to <name>_2, <name>_3 ... (Psych loads them through a comma separated "image").
     * Returns the sheet base names (first = [name]).
     */
    fun packSparrow(groups: List<Group>, dir: File, name: String, pad: Int = 2): List<String> {
        val items = ArrayList<Item>()
        for (g in groups) for ((i, f) in g.frames.withIndex()) {
            val (t, ox, oy) = trim(f)
            items.add(Item("%s%04d".format(g.prefix, i), t, -ox, -oy, f.width, f.height))
        }
        val order = items.indices.sortedBy { -items[it].img.height }
        val tot = items.sumOf { ((it.img.width + pad) * (it.img.height + pad)).toLong() }
        var width = min(MAX_SHEET, max(256, (sqrt(tot.toDouble()) * 1.15).toInt()))
        width = max(width, items.maxOfOrNull { it.img.width + pad } ?: 1)
        val sheets = ArrayList<Sheet>(); var cur = Sheet(); sheets.add(cur)
        val pos = HashMap<Int, Triple<Int, Int, Int>>()          // item -> (sheet, x, y)
        for (k in order) {
            val w = items[k].img.width + pad; val h = items[k].img.height + pad
            if (cur.x + w > width) { cur.x = 0; cur.y += cur.rowH; cur.rowH = 0 }
            if (cur.y + h > MAX_SHEET && cur.placed.isNotEmpty()) { cur = Sheet(); sheets.add(cur) }
            pos[k] = Triple(sheets.size - 1, cur.x, cur.y); cur.placed.add(pos[k]!!)
            cur.x += w; cur.rowH = max(cur.rowH, h); cur.w = max(cur.w, cur.x); cur.h = max(cur.h, cur.y + cur.rowH)
        }
        val names = sheets.indices.map { if (it == 0) name else "${name}_${it + 1}" }
        dir.mkdirs()
        for ((si, sh) in sheets.withIndex()) {
            val sheet = Bitmap.createBitmap(max(1, sh.w), max(1, sh.h), Bitmap.Config.ARGB_8888); val cv = Canvas(sheet)
            val xml = StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<TextureAtlas imagePath=\"${names[si]}.png\">\n")
            for (k in items.indices) {
                val (s2, px, py) = pos[k]!!
                if (s2 != si) continue
                val it = items[k]
                cv.drawBitmap(it.img, px.toFloat(), py.toFloat(), null)
                xml.append("  <SubTexture name=\"${it.name}\" x=\"$px\" y=\"$py\" width=\"${it.img.width}\" height=\"${it.img.height}\" frameX=\"${it.fx}\" frameY=\"${it.fy}\" frameWidth=\"${it.fw}\" frameHeight=\"${it.fh}\"/>\n")
            }
            xml.append("</TextureAtlas>\n")
            ImageOpt.savePng(sheet, File(dir, names[si] + ".png"))
            File(dir, names[si] + ".xml").writeText(xml.toString())
            sheet.recycle()
        }
        items.forEach { it.img.recycle() }
        return names
    }

    /**
     * Cuts one oversized Sparrow sheet (a side > maxDim) into several sheets <name>, <name>_2 ... next to it.
     * Frames keep every attribute (frameX/Y/Width/Height, rotated, pivot ...), only x/y change. Returns the new base names, or null if nothing to do.
     */
    fun splitSparrow(png: File, xml: File, maxDim: Int = MAX_SHEET): List<String>? {
        if (!png.isFile || !xml.isFile) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(png.path, o)
        if (o.outWidth <= maxDim && o.outHeight <= maxDim) return null
        val text = xml.readText()
        val tags = Regex("<SubTexture\\b[^>]*>").findAll(text).map { it.value }.toList()
        if (tags.isEmpty()) return null
        fun at(tag: String, n: String) = Regex("(?<![A-Za-z])$n=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
        class R(val tag: String, val x: Int, val y: Int, val w: Int, val h: Int)
        val rs = ArrayList<R>()
        for (t in tags) {
            val x = at(t, "x")?.toDoubleOrNull()?.toInt() ?: return null; val y = at(t, "y")?.toDoubleOrNull()?.toInt() ?: return null
            var w = at(t, "width")?.toDoubleOrNull()?.toInt() ?: return null; var h = at(t, "height")?.toDoubleOrNull()?.toInt() ?: return null
            if (at(t, "rotated") == "true") { val tmp = w; w = h; h = tmp }
            if (w > maxDim || h > maxDim) return null
            rs.add(R(t, x, y, w, h))
        }
        val src = BitmapFactory.decodeFile(png.path) ?: return null
        val pad = 2
        val order = rs.indices.sortedBy { -rs[it].h }
        val sheets = ArrayList<Sheet>(); var cur = Sheet(); sheets.add(cur)
        val pos = HashMap<Int, Triple<Int, Int, Int>>()
        for (k in order) {
            val w = rs[k].w + pad; val h = rs[k].h + pad
            if (cur.x + w > maxDim) { cur.x = 0; cur.y += cur.rowH; cur.rowH = 0 }
            if (cur.y + h > maxDim && cur.placed.isNotEmpty()) { cur = Sheet(); sheets.add(cur) }
            pos[k] = Triple(sheets.size - 1, cur.x, cur.y); cur.placed.add(pos[k]!!)
            cur.x += w; cur.rowH = max(cur.rowH, h); cur.w = max(cur.w, cur.x); cur.h = max(cur.h, cur.y + cur.rowH)
        }
        val base = png.nameWithoutExtension; val dir = png.parentFile!!
        val names = sheets.indices.map { if (it == 0) base else "${base}_${it + 1}" }
        for ((si, sh) in sheets.withIndex()) {
            val sheet = Bitmap.createBitmap(max(1, sh.w), max(1, sh.h), Bitmap.Config.ARGB_8888); val cv = Canvas(sheet)
            val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<TextureAtlas imagePath=\"${names[si]}.png\">\n")
            for (k in rs.indices) {
                val (s2, px, py) = pos[k]!!
                if (s2 != si) continue
                val r = rs[k]
                val sx = min(r.x, src.width - 1); val sy = min(r.y, src.height - 1)
                cv.drawBitmap(src, Rect(sx, sy, min(src.width, sx + r.w), min(src.height, sy + r.h)), Rect(px, py, px + min(r.w, src.width - sx), py + min(r.h, src.height - sy)), null)
                sb.append("  ").append(r.tag.replace(Regex("(?<![A-Za-z])x=\"[^\"]*\""), "x=\"$px\"").replace(Regex("(?<![A-Za-z])y=\"[^\"]*\""), "y=\"$py\"")).append("\n")
            }
            sb.append("</TextureAtlas>\n")
            ImageOpt.savePng(sheet, File(dir, names[si] + ".png"))
            File(dir, names[si] + ".xml").writeText(sb.toString())
            sheet.recycle()
        }
        src.recycle()
        return names
    }

    /** same, searching several sheets (a character cut into <name>, <name>_2 ...) */
    fun sparrowFirstFrameSize(xmls: List<File>, prefix: String): Pair<Int, Int>? { for (x in xmls) sparrowFirstFrameSize(x, prefix)?.let { return it }; return null }

    /** (frameWidth, frameHeight) of the first frame whose name starts with prefix. */
    fun sparrowFirstFrameSize(xml: File?, prefix: String): Pair<Int, Int>? {
        if (xml == null || !xml.isFile) return null
        val rx = Regex("<SubTexture\\b[^>]*>")
        for (m in rx.findAll(xml.readText())) {
            val tag = m.value
            fun at(n: String) = Regex("\\b$n=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
            if ((at("name") ?: "").lowercase().startsWith(prefix.lowercase())) {
                val w = (at("frameWidth") ?: at("width"))?.toDoubleOrNull() ?: return null
                val h = (at("frameHeight") ?: at("height"))?.toDoubleOrNull() ?: return null
                return w.toInt() to h.toInt()
            }
        }
        return null
    }
}
