package com.portyou.studio.convert

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Lossless PNG optimiser (same idea as optipng / compress2go "PNG"): pixels are never changed.
 *  - <=256 colours  -> indexed PNG (1/2/4/8 bit) with a tRNS chunk, so transparency is kept
 *  - no transparent pixel -> RGB (24 bit) instead of RGBA
 *  - fully transparent pixels get RGB 0 (invisible, but compresses far better)
 *  - best of the 5 PNG row filters per row + Deflate level 9
 * No palette-reduction of real photos/gradients is done, so no blotches or white/black backgrounds appear.
 */
object ImageOpt {
    private val SIG = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    fun savePng(bmp: Bitmap, f: File) {
        f.parentFile?.mkdirs()
        try { f.outputStream().buffered().use { encode(bmp, it) } }
        catch (t: Throwable) { f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }

    /** Re-encodes an existing PNG and keeps the new file only if it is smaller. */
    fun optimizeFile(f: File): Long {
        if (f.length() < 2048) return 0
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0 || o.outWidth.toLong() * o.outHeight > 40_000_000L) return 0
        val b = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inPremultiplied = false }) ?: return 0
        val tmp = File(f.path + ".opt")
        try {
            savePng(b, tmp)
            val saved = f.length() - tmp.length()
            if (saved > 0) { f.delete(); tmp.renameTo(f); return saved }
            tmp.delete(); return 0
        } finally { b.recycle() }
    }

    private fun chunk(o: DataOutputStream, type: String, data: ByteArray) {
        o.writeInt(data.size)
        val t = type.toByteArray(Charsets.US_ASCII)
        o.write(t); o.write(data)
        val c = CRC32(); c.update(t); c.update(data)
        o.writeInt(c.value.toInt())
    }

    private fun paeth(a: Int, b: Int, c: Int): Int {
        val p = a + b - c; val pa = abs(p - a); val pb = abs(p - b); val pc = abs(p - c)
        return if (pa <= pb && pa <= pc) a else if (pb <= pc) b else c
    }

    private fun encode(bmp: Bitmap, os: OutputStream) {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        var opaque = true; var palOk = true
        val pal = HashMap<Int, Int>()
        for (i in px.indices) {
            var p = px[i]
            val a = p ushr 24
            if (a == 0) { p = 0; px[i] = 0 }
            if (a != 255) opaque = false
            if (palOk && !pal.containsKey(p)) { if (pal.size >= 256) palOk = false else pal[p] = pal.size }
        }
        val colorType: Int; val depth: Int; val bpp: Int; val rowLen: Int
        var plte: ByteArray? = null; var trns: ByteArray? = null
        var remap: IntArray? = null; var colors: List<Int> = emptyList()
        if (palOk) {
            colors = pal.keys.sortedBy { if ((it ushr 24) == 255) 1 else 0 }   // see-through entries first -> short tRNS
            val idx = HashMap<Int, Int>(); colors.forEachIndexed { i, c -> idx[c] = i }
            remap = IntArray(px.size) { idx[px[it]]!! }
            colorType = 3; bpp = 1
            depth = when { colors.size <= 2 -> 1; colors.size <= 4 -> 2; colors.size <= 16 -> 4; else -> 8 }
            rowLen = (w * depth + 7) / 8
            plte = ByteArray(colors.size * 3) { k -> val c = colors[k / 3]; when (k % 3) { 0 -> (c shr 16).toByte(); 1 -> (c shr 8).toByte(); else -> c.toByte() } }
            var last = -1; colors.forEachIndexed { i, c -> if ((c ushr 24) != 255) last = i }
            if (last >= 0) trns = ByteArray(last + 1) { (colors[it] ushr 24).toByte() }
        } else if (opaque) { colorType = 2; depth = 8; bpp = 3; rowLen = w * 3 }
        else { colorType = 6; depth = 8; bpp = 4; rowLen = w * 4 }

        val raw = ByteArrayOutputStream(max(1024, w * h / 2))
        val dos = DeflaterOutputStream(raw, Deflater(9), 1 shl 16)
        var cur = ByteArray(rowLen); var prev = ByteArray(rowLen)
        val cand = Array(5) { ByteArray(rowLen + 1) }
        val filters = if (colorType == 3 && depth < 8) intArrayOf(0) else if (w.toLong() * h > 6_000_000L) intArrayOf(1, 2, 4) else intArrayOf(0, 1, 2, 3, 4)
        for (y in 0 until h) {
            java.util.Arrays.fill(cur, 0)
            val base = y * w
            when (colorType) {
                3 -> if (depth == 8) for (x in 0 until w) cur[x] = remap!![base + x].toByte()
                     else { val per = 8 / depth; for (x in 0 until w) { val shift = 8 - depth * (x % per + 1); cur[x / per] = (cur[x / per].toInt() or (remap!![base + x] shl shift)).toByte() } }
                2 -> for (x in 0 until w) { val p = px[base + x]; cur[x * 3] = (p shr 16).toByte(); cur[x * 3 + 1] = (p shr 8).toByte(); cur[x * 3 + 2] = p.toByte() }
                else -> for (x in 0 until w) { val p = px[base + x]; cur[x * 4] = (p shr 16).toByte(); cur[x * 4 + 1] = (p shr 8).toByte(); cur[x * 4 + 2] = p.toByte(); cur[x * 4 + 3] = (p ushr 24).toByte() }
            }
            var bestF = filters[0]; var bestSum = Long.MAX_VALUE
            for (ft in filters) {
                val out = cand[ft]; out[0] = ft.toByte(); var sum = 0L
                for (i in 0 until rowLen) {
                    val a = if (i >= bpp) cur[i - bpp].toInt() and 255 else 0
                    val b = prev[i].toInt() and 255
                    val c = if (i >= bpp) prev[i - bpp].toInt() and 255 else 0
                    val x = cur[i].toInt() and 255
                    val v = when (ft) { 0 -> x; 1 -> x - a; 2 -> x - b; 3 -> x - ((a + b) shr 1); else -> x - paeth(a, b, c) }.toByte()
                    out[i + 1] = v; sum += abs(v.toInt())
                }
                if (sum < bestSum) { bestSum = sum; bestF = ft }
            }
            dos.write(cand[bestF])
            val t = prev; prev = cur; cur = t
        }
        dos.finish(); dos.close()

        val o = DataOutputStream(os)
        o.write(SIG)
        val ihdr = ByteArrayOutputStream().also { val d = DataOutputStream(it); d.writeInt(w); d.writeInt(h); d.writeByte(depth); d.writeByte(colorType); d.writeByte(0); d.writeByte(0); d.writeByte(0) }
        chunk(o, "IHDR", ihdr.toByteArray())
        if (plte != null) chunk(o, "PLTE", plte)
        if (trns != null) chunk(o, "tRNS", trns)
        chunk(o, "IDAT", raw.toByteArray())
        chunk(o, "IEND", ByteArray(0))
        o.flush()
    }
}

/** Post-processing of a finished mod folder: cut oversized character sheets, then losslessly shrink every PNG. */
object ImagePost {
    fun run(modRoot: File, report: MutableList<String>) {
        val images = File(modRoot, "images")
        if (!images.isDirectory) return
        // 1. character json: any listed sheet bigger than 2048 px is cut into several sheets linked by a comma separated "image"
        File(modRoot, "characters").listFiles { f -> f.isFile && f.name.endsWith(".json") }?.forEach { jf ->
            try {
                val j = JSONObject(jf.readText())
                val parts = j.optString("image", "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                val outParts = ArrayList<String>(); var changed = false
                for (p in parts) {
                    val cut = Atlas.splitSparrow(File(images, "$p.png"), File(images, "$p.xml"))
                    if (cut != null) {
                        val dir = p.substringBeforeLast('/', "")
                        cut.forEach { outParts.add(if (dir.isEmpty()) it else "$dir/$it") }
                        changed = true; report.add("big sprite sheet \"$p\" cut into ${cut.size} sheets (<= ${Atlas.MAX_SHEET}px)")
                    } else outParts.add(p)
                }
                if (changed) { j.put("image", outParts.joinToString(",")); jf.writeText(j.toString(1)) }
            } catch (_: Throwable) {}
        }
        // 2. lossless PNG optimisation
        var before = 0L; var after = 0L
        images.walkTopDown().filter { it.isFile && it.extension.lowercase() == "png" }.forEach { f ->
            before += f.length()
            try { ImageOpt.optimizeFile(f) } catch (_: Throwable) {}
            after += f.length()
        }
        if (before > 0) report.add("images: ${before / 1024} KB -> ${after / 1024} KB (lossless, transparency kept, no colour reduction)")
    }
}
