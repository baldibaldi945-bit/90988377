package com.portyou.studio.convert

import org.json.JSONObject
import java.io.File

/**
 * Kotlin port of tools/portyou/hx2lua.py: Haxe (.hx/.hxc, V-Slice + HScript style) -> Psych Engine Lua, PER FUNCTION.
 * A function that cannot be translated with certainty is not guessed: it is reported and left out.
 * Rules come from assets/converter/methods.json ("haxe"), the same file the Python tool uses.
 */
class Hx2Lua(methodsJson: String) {
    class Unconvertible(msg: String) : Exception(msg)
    class Failure(val file: String, val fn: String, val why: String, val code: String)
    class Result { val failed = ArrayList<Failure>(); var ok = 0 }
    class HxFile(val path: File, val kind: String, val event: String?)

    private val kb = JSONObject(methodsJson).optJSONObject("haxe") ?: JSONObject()
    private val callbacks = HashMap<String, String>().also { m -> kb.optJSONObject("callbacks")?.let { o -> o.keys().forEach { k -> m[k.trim()] = o.getString(k) } } }
    private val apiRules = ArrayList<Pair<Regex, String>>()
    private val unsupported = ArrayList<Pair<Regex, String>>()

    init {
        kb.optJSONArray("api_rules")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); apiRules.add(Regex(r.getString(0)) to r.getString(1)) } }
        kb.optJSONArray("unsupported")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); unsupported.add(Regex(r.getString(0)) to r.getString(1)) } }
    }

    // ------------------------------------------------------------------ lexical helpers
    private fun stripComments(src: String): String {
        val out = StringBuilder(); var i = 0; val n = src.length; var q: Char? = null
        while (i < n) {
            val c = src[i]
            if (q != null) {
                out.append(c)
                if (c == '\\' && i + 1 < n) { out.append(src[i + 1]); i += 2; continue }
                if (c == q) q = null
                i++; continue
            }
            if (c == '"' || c == '\'') { q = c; out.append(c); i++; continue }
            if (src.startsWith("//", i)) { while (i < n && src[i] != '\n') i++; continue }
            if (src.startsWith("/*", i)) { val j = src.indexOf("*/", i + 2); i = if (j < 0) n else j + 2; continue }
            out.append(c); i++
        }
        return out.toString()
    }

    private fun matchBrace(src: String, start: Int): Int {
        var i = start; var d = 0; var q: Char? = null; val n = src.length
        while (i < n) {
            val c = src[i]
            if (q != null) {
                if (c == '\\') { i += 2; continue }
                if (c == q) q = null
            } else if (c == '"' || c == '\'') q = c
            else if (c == '{') d++
            else if (c == '}') { d--; if (d == 0) return i }
            i++
        }
        throw Unconvertible("unbalanced braces")
    }

    private sealed class Member {
        class Fn(val name: String, val args: String, val body: String) : Member()
        class Var(val text: String) : Member()
    }

    private val fre = Regex("(?:(?:override|public|private|static|inline)\\s+)*function\\s+(\\w+)\\s*\\(([^)]*)\\)\\s*(?::\\s*[\\w.<>]+)?\\s*\\{")
    private val vre = Regex("(?:(?:public|private|static|inline)\\s+)*(?:var|final)\\s+[^;{]*;")

    private fun splitMembers(source: String): List<Member> {
        val src = stripComments(source)
        var body = src
        Regex("\\bclass\\s+\\w+[^{]*\\{").find(src)?.let { m -> val end = matchBrace(src, m.range.last); body = src.substring(m.range.last + 1, end) }
        val members = ArrayList<Member>(); var i = 0
        while (i < body.length) {
            val f = fre.find(body, i); val v = vre.find(body, i)
            if (f != null && (v == null || f.range.first < v.range.first)) {
                val end = matchBrace(body, f.range.last)
                members.add(Member.Fn(f.groupValues[1], f.groupValues[2], body.substring(f.range.last + 1, end)))
                i = end + 1
            } else if (v != null) { members.add(Member.Var(v.value)); i = v.range.last + 1 } else break
        }
        return members
    }

    // ------------------------------------------------------------------ expressions
    private val strRx = Regex("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'")
    private val leftRx = Regex("\\b(?:game|FlxG|Flx[A-Z]\\w*|Paths|ClientPrefs|PlayState|Conductor)\\.\\w+")

    private fun expand(rep: String, m: MatchResult): String =
        Regex("\\\\(\\d)").replace(rep) { g -> m.groupValues.getOrElse(g.groupValues[1].toInt()) { "" } }

    private fun convExpr(src: String): String {
        var e = src.trim()
        for ((rx, why) in unsupported) if (rx.containsMatchIn(e)) throw Unconvertible(why)
        val strs = ArrayList<String>()
        e = strRx.replace(e) { m -> strs.add(m.value); "\u0000${strs.size - 1}\u0000" }
        for ((rx, rep) in apiRules) e = rx.replace(e) { m -> expand(rep, m) }
        e = Regex("\\bnull\\b").replace(e, "nil")
        e = e.replace("!=", "~=").replace("&&", " and ").replace("||", " or ")
        e = Regex("!(?!=)\\s*").replace(e, "not ")
        e = Regex("\\bthis\\.").replace(e, "")
        e = Regex(":\\s*(?:Int|Float|String|Bool|Dynamic|Array<\\w+>)\\b").replace(e, "")
        e = Regex("\\bStd\\.int\\(([^()]*)\\)").replace(e) { "math.floor(${it.groupValues[1]})" }
        e = Regex("\\bMath\\.(floor|ceil|abs|sin|cos|sqrt|min|max|random|pow)\\b").replace(e) { "math." + it.groupValues[1] }
        e = Regex("\\bMath\\.PI\\b").replace(e, "math.pi")
        e = Regex("\\bMath\\.round\\(([^()]*)\\)").replace(e) { "math.floor((${it.groupValues[1]}) + 0.5)" }
        e = Regex("\\b(\\w+)\\.length\\b").replace(e) { "#" + it.groupValues[1] }
        e = Regex("\\bmath\\.pow\\(([^,()]+),\\s*([^()]+)\\)").replace(e) { "(${it.groupValues[1]} ^ ${it.groupValues[2]})" }
        if (e.contains('\u0000')) {      // '+' next to a string literal is concatenation
            e = Regex("(\u0000\\d+\u0000)\\s*\\+").replace(e) { it.groupValues[1] + " .." }
            e = Regex("\\+\\s*(\u0000\\d+\u0000)").replace(e) { ".. " + it.groupValues[1] }
            e = Regex("\\.\\.\\s*(\\w[\\w.\\[\\]()]*)\\s*\\+\\s*(?=\u0000|\\w)").replace(e) { ".. ${it.groupValues[1]} .. " }
        }
        if (Regex("\\[\\s*\\]").matches(e)) e = "{}"
        if (Regex("\\[[^\\]]*\\]").matches(e) && !Regex("\\w\\[").containsMatchIn(e)) e = "{" + e.substring(1, e.length - 1) + "}"
        for ((i, sx) in strs.withIndex()) e = e.replace("\u0000$i\u0000", sx)
        val bare = strRx.replace(e, "")
        leftRx.find(bare)?.let { throw Unconvertible("engine API without a Lua equivalent yet: " + it.value) }
        // ---- generic guards: anything left here is NOT valid Psych Lua, so it must never be written into a script
        run {
            val masked = bare   // string literals removed
            if (masked.contains('?')) throw Unconvertible("ternary / null-safe operator")
            Regex("(?<![\\w.])(?!(?:math|string|table|os)\\b)[A-Z][A-Za-z0-9_]*\\.[A-Za-z_]\\w*").find(masked)?.let { throw Unconvertible("engine class API without a Lua equivalent yet: " + it.value) }
            Regex("\\b(?!(?:table|string|math|os)\\b)\\w+\\)?\\.(?:get|set|getBool|getFloat|getInt|getString|push|pop|add|remove|indexOf|exists|keys|playAnimation|flush|contains|copy|join|split|substr|charAt|toString)\\(").find(masked)?.let { throw Unconvertible("object method call has no Psych Lua equivalent: " + it.value) }
        }
        if (e.contains("=>") || e.contains("->") || Regex("\\bnew\\s+\\w").containsMatchIn(e)) throw Unconvertible("lambda / constructor / map literal")
        return e.trim()
    }

    private fun convBlock(body: String, indent: Int = 1): List<String> {
        val out = ArrayList<String>()
        for (st in splitStatements(body)) out += convStmt(st.trim(), indent)
        return out
    }

    private fun splitStatements(body: String): List<String> {
        val res = ArrayList<String>(); var cur = StringBuilder(); var d = 0; var q: Char? = null; var i = 0; val n = body.length
        while (i < n) {
            val c = body[i]
            if (q != null) {
                cur.append(c)
                if (c == '\\' && i + 1 < n) { cur.append(body[i + 1]); i += 2; continue }
                if (c == q) q = null
                i++; continue
            }
            if (c == '"' || c == '\'') { q = c; cur.append(c) }
            else if (c == '(' || c == '[') { d++; cur.append(c) }
            else if (c == ')' || c == ']') { d--; cur.append(c) }
            else if (c == '{' && d == 0) {
                val end = matchBrace(body, i)
                cur.append(body, i, end + 1); i = end + 1
                val rest = body.substring(i).trimStart()
                if (Regex("^(else|catch)\\b").containsMatchIn(rest)) continue
                if (cur.isNotBlank()) res.add(cur.toString())
                cur = StringBuilder(); continue
            } else if (c == ';' && d == 0) { if (cur.isNotBlank()) res.add(cur.toString()); cur = StringBuilder() }
            else cur.append(c)
            i++
        }
        if (cur.isNotBlank()) res.add(cur.toString())
        return res
    }

    private fun headAndBlock(st: String, kw: String): Pair<String, String>? {
        val m = Regex("^$kw\\s*\\(").find(st) ?: return null
        val i = m.range.last; var d = 0
        for (j in i until st.length) {
            if (st[j] == '(') d++ else if (st[j] == ')') { d--; if (d == 0) return st.substring(i + 1, j) to st.substring(j + 1).trim() }
        }
        throw Unconvertible("unbalanced parentheses")
    }

    private fun blockOf(rest0: String): Pair<String, String> {
        val rest = rest0.trim()
        if (rest.startsWith("{")) { val end = matchBrace(rest, 0); return rest.substring(1, end) to rest.substring(end + 1).trim() }
        val parts = splitStatements(rest)
        return (parts.firstOrNull() ?: "") to ""
    }

    private val reLocal = Regex("(?:final|var)\\s+(\\w+)\\s*(?::\\s*[\\w.<>]+)?\\s*(?:=\\s*(.*))?", RegexOption.DOT_MATCHES_ALL)
    private val reCompound = Regex("(.+?)\\s*([+\\-*/])=\\s*(.+)", RegexOption.DOT_MATCHES_ALL)
    private val reIncr = Regex("(\\w[\\w.\\[\\]]*)\\s*(\\+\\+|--)")
    private val reAssign1 = Regex("([^=<>!]+?)\\s=\\s(?!=)(.+)", RegexOption.DOT_MATCHES_ALL)
    private val reAssign2 = Regex("([\\w.\\[\\]()'\"]+)\\s*=(?!=)\\s*(.+)", RegexOption.DOT_MATCHES_ALL)

    private fun convStmt(st: String, ind: Int): List<String> {
        val pad = "\t".repeat(ind)
        if (st.isEmpty()) return emptyList()
        if (Regex("^(switch|try|do)\\b").containsMatchIn(st)) throw Unconvertible("switch / try / do-while")
        headAndBlock(st, "if")?.let { (cond0, rest0) ->
            var cond = cond0; var rest = rest0; val lines = ArrayList<String>(); var first = true
            while (true) {
                val (body, r1) = blockOf(rest); rest = r1
                lines.add("$pad${if (first) "if" else "elseif"} ${convExpr(cond)} then")
                lines += convBlock(body, ind + 1); first = false
                if (rest.startsWith("else")) {
                    rest = rest.substring(4).trim()
                    val r2 = headAndBlock(rest, "if")
                    if (r2 != null) { cond = r2.first; rest = r2.second; continue }
                    val (b2, r3) = blockOf(rest); rest = r3
                    lines.add(pad + "else"); lines += convBlock(b2, ind + 1)
                }
                break
            }
            lines.add(pad + "end"); return lines
        }
        headAndBlock(st, "for")?.let { (head, rest) ->
            val (body, _) = blockOf(rest)
            val lines = ArrayList<String>()
            val m = Regex("\\s*(\\w+)\\s+in\\s+(.+?)\\.\\.\\.(.+)").matchEntire(head)
            if (m != null) lines.add("${pad}for ${m.groupValues[1]} = ${convExpr(m.groupValues[2])}, ${convExpr("(${m.groupValues[3]}) - 1")} do")
            else {
                val m2 = Regex("\\s*(\\w+)\\s+in\\s+(.+)").matchEntire(head) ?: throw Unconvertible("for-loop form")
                lines.add("${pad}for _, ${m2.groupValues[1]} in ipairs(${convExpr(m2.groupValues[2])}) do")
            }
            lines += convBlock(body, ind + 1); lines.add(pad + "end"); return lines
        }
        headAndBlock(st, "while")?.let { (cond, rest) ->
            val (body, _) = blockOf(rest)
            return listOf("${pad}while ${convExpr(cond)} do") + convBlock(body, ind + 1) + listOf(pad + "end")
        }
        if (st.startsWith("{")) { val end = matchBrace(st, 0); return listOf(pad + "do") + convBlock(st.substring(1, end), ind + 1) + listOf(pad + "end") }
        if (st.startsWith("return")) { val v = st.substring(6).trim(); return listOf(pad + if (v.isNotEmpty()) "return " + convExpr(v) else "do return end") }
        if (st == "break" || st == "continue") {
            if (st == "continue") throw Unconvertible("continue (no Lua equivalent without goto)")
            return listOf(pad + "break")
        }
        reLocal.matchEntire(st)?.let { m -> return listOf("${pad}local ${m.groupValues[1]}" + (if (m.groups[2] != null && m.groupValues[2].isNotEmpty()) " = " + convExpr(m.groupValues[2]) else "")) }
        reCompound.matchEntire(st)?.let { m ->
            if (!Regex("[=<>!]=").containsMatchIn(m.groupValues[1])) {
                val t = convExpr(m.groupValues[1])
                val op = if (m.groupValues[2] == "+" && Regex("'|\"").containsMatchIn(m.groupValues[3])) ".." else m.groupValues[2]
                return listOf("$pad$t = $t $op ${convExpr(m.groupValues[3])}")
            }
        }
        reIncr.matchEntire(st)?.let { m -> return listOf("$pad${m.groupValues[1]} = ${m.groupValues[1]} ${m.groupValues[2][0]} 1") }
        (reAssign1.matchEntire(st) ?: reAssign2.matchEntire(st))?.let { m -> return listOf("$pad${convExpr(m.groupValues[1])} = ${convExpr(m.groupValues[2])}") }
        return listOf(pad + convExpr(st))
    }

    /** guards odd output: every opener has its end, brackets match */
    private fun luaBalanced(code0: String): Boolean {
        val code = Regex("'(?:\\\\.|[^'\\\\])*'|\"(?:\\\\.|[^\"\\\\])*\"|--[^\\n]*").replace(code0, "")
        val opens = Regex("\\b(function|if|for|while|do)\\b").findAll(code).count() -
            Regex("\\bfor\\b[^\\n]*\\bdo\\b|\\bwhile\\b[^\\n]*\\bdo\\b").findAll(code).count()
        return opens == Regex("\\bend\\b").findAll(code).count() && code.count { it == '(' } == code.count { it == ')' } && code.count { it == '{' } == code.count { it == '}' }
    }

    // ------------------------------------------------------------------ file level
    fun convertSource(src: String, kind: String, name: String): Pair<String, Result> {
        val r = Result(); val lines = ArrayList<String>(); lines.add("-- PortYou Studio: converted from $name ($kind)")
        val members = splitMembers(src)
        if (members.isEmpty()) r.failed.add(Failure(name, "<file>", "no functions or variables recognised", src.trim().take(4000)))
        for (mem in members) {
            when (mem) {
                is Member.Var -> try {
                    lines += convStmt(mem.text.trim().trimEnd(';').replace("public ", "").replace("static ", "").replace("private ", ""), 0)
                } catch (ex: Unconvertible) { r.failed.add(Failure(name, "<variable>", ex.message ?: "", mem.text)) }
                is Member.Fn -> {
                    if (mem.name == "new" || mem.name == "getEventSchema" || mem.name == "getTitle") continue   // editor-only metadata, Psych has no use for it
                    val lname = callbacks[mem.name] ?: mem.name
                    val params = mem.args.split(',').map { it.replace(Regex("\\s*[:=].*$"), "").trim() }.filter { it.isNotEmpty() }
                    try {
                        val code = convBlock(mem.body)
                        // every converted callback runs inside pcall: a missing API can never pop up "Error on lua script!" in game
                        val lua = (listOf("function $lname(${params.joinToString(", ")})", "\tlocal __ok, __r = pcall(function()") + code.map { "\t" + it } +
                            listOf("\tend)", "\tif __ok then return __r end", "end")).joinToString("\n")
                        if (!luaBalanced(lua)) throw Unconvertible("result did not pass the syntax balance check")
                        lines.add(lua); r.ok++
                    } catch (ex: Unconvertible) {
                        r.failed.add(Failure(name, mem.name, ex.message ?: "", "function ${mem.name}(${mem.args}) {${mem.body}}"))
                        lines.add("-- PortYou: function \"${mem.name}\" was NOT converted (${ex.message})")
                    } catch (ex: StackOverflowError) {
                        r.failed.add(Failure(name, mem.name, "too deeply nested", "function ${mem.name}(${mem.args}) {${mem.body}}"))
                    }
                }
            }
        }
        return lines.joinToString("\n") + "\n" to r
    }

    /** V-Slice SongEvent.handleEvent(data) -> Psych custom event onEvent(name, v1, v2); data.value = parsed 'k=v;k=v' */
    private fun eventWrapper(kind: String, lua0: String): String {
        val lua = lua0.replace(Regex("\\bfunction handleEvent\\("), "local function handleEvent(")
        val pre = "local function _parse(s) local t = {} for kv in string.gmatch(s or \"\", \"[^;]+\") do local k, v = string.match(kv, \"^([^=]+)=(.*)\$\") " +
            "if k then t[k] = tonumber(v) or (v == \"true\" and true) or (v == \"false\" and false) or v end end return t end\n"
        val q = "'" + kind.replace("\\", "\\\\").replace("'", "\\'") + "'"
        return pre + lua + "\nfunction onEvent(name, v1, v2)\n\tif name == $q then pcall(handleEvent, {value = _parse(v1), event = name}) end\nend\n"
    }

    /** Writes Lua into outDir (the mod root). Whatever cannot be converted is written OUT of the mod into unconvertedDir with a 4-language report. */
    fun convertMany(files: List<HxFile>, outDir: File, unconvertedDir: File): Pair<Int, List<Failure>> {
        val failures = ArrayList<Failure>(); var okFiles = 0
        for (f in files) {
            val base = f.path.nameWithoutExtension
            val res: Pair<String, Result> = try { convertSource(f.path.readText(), f.kind, f.path.name) }
                catch (ex: Exception) { failures.add(Failure(f.path.name, "<file>", ex.message ?: "", "")); continue }
            var lua = res.first; val r = res.second
            if (r.ok > 0) {
                val dest: File = when (f.kind) {
                    "event" -> { lua = eventWrapper(f.event ?: base, lua); File(outDir, "custom_events/${f.event ?: base}.lua") }
                    "stage" -> File(outDir, "stages/$base.lua").also { if (it.isFile) lua = it.readText() + "\n" + lua }
                    else -> File(outDir, "scripts/hx_$base.lua")
                }
                dest.parentFile?.mkdirs(); dest.writeText(lua); okFiles++
            }
            failures += r.failed
        }
        if (failures.isNotEmpty()) writeUnconverted(failures, unconvertedDir)
        return okFiles to failures
    }

    private val head = mapOf(
        "ar" to "ماقدرت أحول هذا — أجزاء من أكواد الهاكس لم يستطع المحوّل تحويلها إلى لوا. تم فصلها عن المود وهذه قائمتها:",
        "en" to "Could not convert this — parts of the Haxe code could not be turned into Lua. They were separated from the mod; here is the list:",
        "pt" to "Não consegui converter isto — partes do código Haxe não puderam virar Lua. Foram separadas do mod; segue a lista:",
        "ja" to "これは変換できませんでした — Haxeコードの一部をLuaに変換できませんでした。MODから分離済みです。一覧:")

    private fun writeUnconverted(failures: List<Failure>, d: File) {
        d.mkdirs()
        val txt = ArrayList<String>()
        for ((l, h) in head) txt.add("=".repeat(60) + "\n[$l] $h\n")
        txt.add("=".repeat(60))
        for (f in failures) txt.add("\n* ${f.file} :: ${f.fn}\n    reason: ${f.why}")
        File(d, "ماقدرت_احول_ذا_COULD_NOT_CONVERT.txt").writeText(txt.joinToString("\n") + "\n")
        val raw = File(d, "haxe_sources").also { it.mkdirs() }
        for (f in failures) if (f.code.isNotEmpty()) File(raw, "${f.file.substringBeforeLast('.')}__${f.fn.replace(Regex("\\W"), "_")}.hx").writeText(f.code)
    }
}
