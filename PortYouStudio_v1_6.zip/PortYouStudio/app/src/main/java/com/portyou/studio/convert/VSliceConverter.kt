package com.portyou.studio.convert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.TreeMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// ---- small JSON helpers (org.json has no defaults for nested access) ----
private fun JSONObject.o(k: String): JSONObject = optJSONObject(k) ?: JSONObject()
private fun JSONObject.a(k: String): JSONArray = optJSONArray(k) ?: JSONArray()
private fun JSONObject.s(k: String, def: String = ""): String = if (has(k) && !isNull(k)) optString(k, def) else def
private fun JSONObject.d(k: String, def: Double): Double = if (has(k) && !isNull(k)) optDouble(k, def) else def
private fun JSONObject.b(k: String, def: Boolean = false): Boolean = if (has(k) && !isNull(k)) optBoolean(k, def) else def
private fun JSONArray.objs(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
private fun JSONArray.strs(): List<String> = (0 until length()).map { optString(it) }
private fun JSONArray.dbl(i: Int, def: Double = 0.0): Double = if (i < length() && !isNull(i)) optDouble(i, def) else def
private fun ns(x: Any?): String = when (x) {
    null -> "0"
    is Double -> if (x == Math.floor(x) && abs(x) < 1e12) x.toLong().toString() else x.toString()
    is Float -> ns(x.toDouble())
    else -> x.toString()
}
private fun lua(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"

/** Kotlin port of tools/portyou/vslice.py (V-Slice 2.x mod -> Psych Engine 1.0.x mod). */
class VSliceConverter(private val ctx: Context) {
    private class CharInfo(val psych: JSONObject?, val dance: Int, val cam: DoubleArray, val icon: String, val empty: Boolean)
    private class SongInfo(val id: String, val name: String) { val diffs = ArrayList<String>(); val psychIds = ArrayList<String>() }
    private class Sec(val start: Double, val end: Double, val beats: Double, val bpm: Double, val change: Boolean)

    private val methods: JSONObject = JSONObject(ctx.assets.open("converter/methods.json").bufferedReader().readText()).getJSONObject("vslice")
    private val hx = Hx2Lua(ctx.assets.open("converter/methods.json").bufferedReader().readText())
    private val noteKinds = methods.o("note_kinds")
    private val evMap = methods.o("events")

    private lateinit var root: File
    private lateinit var out: File
    private lateinit var outRoot: File
    private var meta = JSONObject()
    private var title = "mod"
    private var slugName = "mod"
    private val chars = LinkedHashMap<String, CharInfo?>()
    private val charSizes = HashMap<String, DoubleArray>()
    private val emptyChars = HashSet<String>()
    private var emptyPre: Set<String>? = null
    private val hxFiles = ArrayList<Hx2Lua.HxFile>()
    private val dropped = ArrayList<String>()
    private val rMethods = ArrayList<String>()
    private var rWarn: MutableList<String> = ArrayList()
    private val imageDirs: List<File> get() = listOf(File(root, "images"), File(root, "shared/images"))

    private val unknownKinds = sortedSetOf<String>()
    private val unmappedEvents = sortedSetOf<String>()
    /** how the charts use each unmapped event / unknown note kind - the Brain reads this to understand them */
    private val evSamples = HashMap<String, MutableList<Pair<String, String>>>()
    private val noteUse = HashMap<String, IntArray>()   // kind -> [count, player, opponent, sustain]
    private val modShaders: List<String> by lazy { try { root.walkTopDown().filter { it.isFile && it.extension.equals("frag", true) }.map { it.name }.toList() } catch (_: Exception) { emptyList<String>() } }
    private fun usageOf(kind: String): Brain.NoteUsage? = noteUse[kind]?.let { Brain.NoteUsage(it[0], it[1], it[2], it[3]) }
    private fun m(s: String) { if (s !in rMethods) rMethods.add(s) }
    private fun w(s: String) { if (s !in rWarn) rWarn.add(s) }
    private fun P(vararg p: String) = File(out, p.joinToString("/"))
    private fun jload(f: File) = Atlas.loadJson(f)
    private fun jsave(f: File, o: Any) { f.parentFile?.mkdirs(); f.writeText(if (o is JSONObject) o.toString(1) else (o as JSONArray).toString(1)) }
    private fun slug(s: String, fb: String = "mod"): String { val r = s.lowercase().replace(Regex("[^a-z0-9_-]+"), "-").trim('-'); return if (r.count { it.isLetterOrDigit() } >= 2) r else fb }

    // ------------------------------------------------------------------ locating assets
    private fun findRoot(start: File): File {
        start.walkTopDown().maxDepth(4).forEach { f ->
            if (f.isDirectory && (File(f, "_polymod_meta.json").isFile || File(f, "data/songs").isDirectory)) return f
        }
        return start
    }
    private fun findAsset(rel0: String, ext: String = ".png"): File? {
        val rel = rel0.substringAfterLast(':')
        for (d in imageDirs) {
            val p = File(d, rel + ext)
            if (p.isFile) return p
            p.parentFile?.listFiles()?.firstOrNull { it.name.equals(p.name, ignoreCase = true) && it.isFile }?.let { return it }
        }
        return null
    }
    private fun findAssetDir(rel0: String): File? {
        val rel = rel0.substringAfterLast(':')
        return imageDirs.map { File(it, rel) }.firstOrNull { it.isDirectory }
    }

    // ------------------------------------------------------------------ entry point (called from MainActivity)
    fun convert(modRoot: File, outParent: File, originalName: String, report: MutableList<String>): String {
        root = findRoot(modRoot)
        val metaF = File(root, "_polymod_meta.json")
        meta = if (metaF.isFile) try { jload(metaF) } catch (e: Exception) { JSONObject() } else JSONObject()
        // the converted mod keeps the ORIGINAL mod's name: archive file name -> folder name -> first song -> (last) the title inside the meta file
        val fileBase = originalName.substringBeforeLast('.').trim()
        val songDir = File(root, "data/songs").listFiles { f -> f.isDirectory }?.minByOrNull { it.name }?.name ?: ""
        title = listOf(fileBase, root.name.takeIf { it != "x" } ?: "", songDir).firstOrNull { slug(it, "").isNotEmpty() }
            ?: meta.s("title").ifEmpty { root.name }
        slugName = slug(title)
        outRoot = outParent
        out = File(outParent, slugName); out.deleteRecursively(); out.mkdirs()
        rWarn = report
        val songs = convertSongs()
        convertCharacters()
        convertStages()
        convertScripts()
        writeMissingScripts()
        if (!P("scripts", "portyou_vslice.lua").isFile) writeRuntime(mapOf("boyfriend" to doubleArrayOf(0.0, 0.0, 2.0), "dad" to doubleArrayOf(0.0, 0.0, 2.0), "gf" to doubleArrayOf(0.0, 0.0, 2.0)), 1.0)
        copyRemainingAssets()
        ImagePost.run(out, report)
        writeWeeks(songs)
        Credits.write(ctx, out, title)
        m("credits: pack.json (English + Portuguese only) + pack.png + scripts/portyou_credit.lua (\"Port You Studio\") added")
        writeReport()
        return slugName
    }

    // ------------------------------------------------------------------ songs
    private fun convertSongs(): List<SongInfo> {
        val res = ArrayList<SongInfo>()
        val dirs = File(root, "data/songs").listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: return res
        for (d in dirs) {
            if (d.listFiles()?.any { it.name.contains("-chart") && it.name.endsWith(".json") } != true) continue
            res.add(convertSong(d.name, d))
        }
        return res
    }

    private fun convertSong(sid: String, d: File): SongInfo {
        val files = d.listFiles()?.filter { it.isFile && it.name.endsWith(".json") } ?: emptyList()
        val metaFiles = files.filter { it.name.startsWith("$sid-metadata") }.associateBy { it.name.substring(sid.length + 1, it.name.length - 5) }
        val chartFiles = files.filter { it.name.startsWith("$sid-chart") }.associateBy { it.name.substring(sid.length + 1, it.name.length - 5) }
        val baseF = metaFiles["metadata"] ?: metaFiles.values.firstOrNull()
        if (baseF == null) w("song $sid has no metadata json (default bpm 120 / default characters used)")
        val baseMeta = if (baseF != null) jload(baseF) else JSONObject()
        val info = SongInfo(sid, baseMeta.s("songName", sid))
        for ((ck, cf) in chartFiles.toSortedMap()) {
            val variation = ck.removePrefix("chart").trimStart('-')
            val mf = metaFiles["metadata" + (if (variation.isNotEmpty()) "-$variation" else "")]
            val mt = if (mf != null) jload(mf) else baseMeta
            val pid = if (variation.isEmpty()) sid else "$sid-$variation"
            convertChart(pid, sid, variation, mt, jload(cf), info)
        }
        return info
    }

    private fun bpmMap(mt: JSONObject): List<JSONObject> {
        val a = mt.optJSONArray("timeChanges")
        val l = a?.objs() ?: emptyList()
        if (l.isEmpty()) return listOf(JSONObject().put("t", 0).put("bpm", 120).put("bt", JSONArray("[4,4,4,4]")))
        return l.sortedBy { it.d("t", 0.0) }
    }

    /** Sections follow the V-Slice measure grid; a section is cut at every time change. */
    private fun buildSections(tcs: List<JSONObject>, endMs: Double): List<Sec> {
        val secs = ArrayList<Sec>(); var t = 0.0; var i = 0
        while (t < endMs + 1) {
            while (i + 1 < tcs.size && tcs[i + 1].d("t", 0.0) <= t + 0.5) i++
            val tc = tcs[i]
            val bpm = tc.d("bpm", 120.0).let { if (it <= 0) 120.0 else it }
            var beats = tc.optJSONArray("bt")?.dbl(0, 4.0) ?: 4.0
            if (beats <= 0) beats = 4.0
            val crochet = 60000.0 / bpm
            var secLen = beats * crochet
            if (i + 1 < tcs.size && tcs[i + 1].d("t", 0.0) < t + secLen - 0.5) { secLen = tcs[i + 1].d("t", 0.0) - t; beats = secLen / crochet }
            if (secLen <= 0.5) secLen = crochet * 4
            secs.add(Sec(t, t + secLen, beats, bpm, secs.isEmpty() || abs(t - tc.d("t", 0.0)) < 0.5))
            t += secLen
        }
        return secs
    }

    private fun focusChar(v: Any?): Int {
        var x = v
        if (x is JSONObject) x = x.opt("char") ?: 0
        if (x is Number) return x.toInt()
        val s = x?.toString() ?: ""
        s.toDoubleOrNull()?.let { return it.toInt() }
        return when (s.lowercase()) { "bf", "boyfriend", "player" -> 0; "dad", "opponent" -> 1; "gf", "girlfriend" -> 2; else -> 0 }
    }

    private fun convertChart(pid: String, sid: String, variation: String, mt: JSONObject, chart: JSONObject, info: SongInfo) {
        val play = mt.o("playData"); val ch = play.o("characters")
        val tcs = bpmMap(mt)
        val notesByDiff = chart.o("notes"); val speeds = chart.o("scrollSpeed")
        val events = chart.a("events").objs()
        val diffs = notesByDiff.keys().asSequence().toList()
        val player = ch.s("player", "bf"); val opp = ch.s("opponent", "dad"); val gf = ch.s("girlfriend", "gf")
        for (c in listOf(player, opp, gf)) if (c !in chars) chars[c] = null
        val evs = convertEvents(events)
        mt.o("offsets").let { if (it.has("instrumental") && it.d("instrumental", 0.0) != 0.0) w("instrumental offset ${it.opt("instrumental")} ms is not applied to the chart") }
        val focus = events.filter { it.s("e") == "FocusCamera" }.map { it.d("t", 0.0) to focusChar(it.opt("v")) }.sortedWith(compareBy({ it.first }, { it.second }))
        m("chart: V-Slice 2.x -> Psych v1 (absolute lanes: player 0-3 / opponent 4-7, never flipped by sections; GF notes -> GF Sing; bpm/time changes kept)")
        val emptyPre = emptyCharsPre()
        for (diff in diffs) {
            val notes = notesByDiff.a(diff).objs()
            val end = max(0.0, max(notes.maxOfOrNull { it.d("t", 0.0) + it.d("l", 0.0) } ?: 0.0, events.maxOfOrNull { it.d("t", 0.0) } ?: 0.0)) + 8000.0
            val secs = buildSections(tcs, end)
            val secOut = secs.map { s ->
                var must = true
                for ((ft, c) in focus) { if (ft <= s.start + 1) must = (c == 0) else break }
                JSONObject().put("sectionNotes", JSONArray()).put("sectionBeats", s.beats).put("mustHitSection", must).put("gfSection", false)
                    .put("bpm", s.bpm).put("changeBPM", s.change && s.start > 0)
            }
            var si = 0
            for (n in notes.sortedWith(compareBy({ it.d("t", 0.0) }, { it.d("d", 0.0) }))) {
                val t = n.d("t", 0.0)
                while (si + 1 < secs.size && t >= secs[si].end - 0.01) si++
                // V-Slice: d 0-3 = player strumline, 4-7 = opponent. Psych 'psych_v1': ABSOLUTE lanes, never flipped by mustHitSection.
                val dd = n.d("d", 0.0).toInt()
                val isPlayer = (dd % 8) < 4
                val data = (dd % 4) + (if (isPlayer) 0 else 4)
                val kRaw = n.opt("k"); val kind = if (kRaw is String) kRaw else ""
                val ptype: String
                if (kind.lowercase() in listOf("gf", "gf sing", "gfsing", "girlfriend", "gfnote")) ptype = "GF Sing"
                else {
                    ptype = if (noteKinds.has(kind)) noteKinds.getString(kind) else kind
                    if (kind.isNotEmpty() && !noteKinds.has(kind)) unknownKinds.add(kind)
                }
                if (kind.isNotEmpty()) {
                    val u = noteUse.getOrPut(kind) { IntArray(4) }
                    u[0]++; if (isPlayer) u[1]++ else u[2]++; if (n.d("l", 0.0) > 0) u[3]++
                }
                secOut[si].getJSONArray("sectionNotes").put(JSONArray().put(t).put(data).put(n.d("l", 0.0)).put(ptype))
            }
            val speed = if (speeds.has(diff)) speeds.d(diff, 2.0) else speeds.d("default", 2.0)
            val chartJson = JSONObject().put("song", pid).put("notes", JSONArray(secOut)).put("events", evs).put("bpm", tcs[0].d("bpm", 120.0)).put("needsVoices", true)
                .put("speed", speed).put("offset", 0).put("player1", player).put("player2", opp).put("gfVersion", if (gf in emptyPre) "gf" else gf)
                .put("stage", play.s("stage", "mainStage")).put("format", "psych_v1").put("arrowSkin", "").put("splashSkin", "noteSplashes/noteSplashes").put("disableNoteRGB", false)
            val fname = if (diff.lowercase() == "normal") pid else "$pid-${diff.lowercase()}"
            jsave(P("data", pid, "$fname.json"), chartJson)
            info.diffs.add(diff.lowercase().replaceFirstChar { it.uppercase() })
            m("difficulty file naming: $pid.json = Normal, <song>-<diff>.json for the others (this mod: $diff)")
        }
        info.psychIds.add(pid)
        convertAudio(pid, sid, variation, play)
    }

    /** Characters whose atlas is a stripped placeholder (checked before characters are converted). */
    private fun emptyCharsPre(): Set<String> {
        emptyPre?.let { return it }
        val set = HashSet<String>()
        File(root, "data/characters").listFiles { f -> f.name.endsWith(".json") }?.forEach { f ->
            try {
                val d = jload(f)
                if (d.s("renderType") in listOf("animateatlas", "atlas")) {
                    val ad = findAssetDir(d.s("assetPath"))
                    if (ad != null && File(ad, "Animation.json").isFile) {
                        if (Atlas.atlasIsPlaceholder(ad)) set.add(f.name.removeSuffix(".json"))
                    }
                }
            } catch (e: Exception) { }
        }
        emptyPre = set; return set
    }

    // ------------------------------------------------------------------ audio
    private fun convertAudio(pid: String, sid: String, variation: String, play: JSONObject) {
        val src = File(root, "songs/$sid"); val dst = P("songs", pid); dst.mkdirs()
        if (!src.isDirectory) { w("songs/$sid missing in the mod (add the audio files for the mod owner)"); return }
        val suffix = if (variation.isNotEmpty()) "-$variation" else ""
        val inst = listOf("Inst$suffix.ogg", "Inst.ogg").map { File(src, it) }.firstOrNull { it.isFile }
        if (inst != null) inst.copyTo(File(dst, "Inst.ogg"), overwrite = true) else w("no Inst.ogg for $pid")
        val ch = play.o("characters")
        val groups = listOf("Player" to ch.a("playerVocals").strs(), "Opponent" to ch.a("opponentVocals").strs())
        for ((g, names) in groups) {
            val files = names.mapNotNull { n -> listOf("Voices-$n$suffix.ogg", "Voices-$n.ogg").map { File(src, it) }.firstOrNull { it.isFile } }
            if (files.isEmpty()) continue
            val ok = AudioMerge.merge(files, File(dst, "Voices-$g.ogg"))
            if (!ok) w("could not merge the vocals of $pid ($g) - only the first file was used")
            m("vocals: every file of a group (${g.lowercase()}) merged into Voices-$g.ogg (Psych 1.0 loads Player/Opponent vocals)")
        }
        if (groups.none { File(dst, "Voices-${it.first}.ogg").isFile }) {
            val lone = File(src, "Voices$suffix.ogg"); if (lone.isFile) lone.copyTo(File(dst, "Voices.ogg"), overwrite = true)
        }
    }

    // ------------------------------------------------------------------ events
    private fun target(t0: Any?): String = when (t0.toString().lowercase()) { "dad", "opponent", "1" -> "dad"; "gf", "girlfriend", "2" -> "gf"; else -> "bf" }
    private fun flat(v: JSONObject): String = v.keys().asSequence().joinToString(";") { k ->
        val x = v.opt(k)
        val s = when (x) { is Boolean -> if (x) "1" else "0"; is Double -> ns(x); else -> x.toString() }
        "$k=${s.replace(";", ",")}"
    }

    private fun convertEvents(events: List<JSONObject>): JSONArray {
        val out = TreeMap<Double, MutableList<JSONArray>>()
        for (e in events.sortedBy { it.d("t", 0.0) }) {
            val kind = e.s("e"); val v = e.optJSONObject("v") ?: JSONObject()
            val mm = evMap.optJSONObject(kind)
            val row: JSONArray
            if (mm == null) {
                unmappedEvents.add(kind)
                evSamples.getOrPut(kind) { ArrayList() }.let { l ->
                    if (l.size < 200) { val vals = v.keys().asSequence().map { k -> val x = v.opt(k); if (x is Boolean) (if (x) "true" else "false") else if (x is Double) ns(x) else x.toString() }.toList(); l.add((vals.getOrNull(0) ?: "") to (vals.getOrNull(1) ?: "")) }
                }
                row = JSONArray().put(kind).put(flat(v)).put("")
            } else if (mm.s("kind") == "psych") {
                row = when (kind) {
                    "PlayAnimation" -> JSONArray().put("Play Animation").put(v.s("anim", "idle")).put(target(v.opt("target") ?: "boyfriend"))
                    "AddCameraZoom" -> JSONArray().put("Add Camera Zoom").put(ns(v.d("game", 0.015))).put(ns(v.d("hud", 0.03)))
                    else -> JSONArray().put(mm.s("name")).put("").put("")
                }
                m("event $kind -> Psych \"${mm.s("name")}\"")
            } else {
                row = JSONArray().put(mm.s("name")).put(flat(v)).put("")
                m("event $kind -> runtime ${mm.s("name")} (scripts/portyou_vslice.lua)")
            }
            out.getOrPut(e.d("t", 0.0)) { ArrayList() }.add(row)
        }
        val res = JSONArray()
        for ((t, rows) in out) res.put(JSONArray().put(t).put(JSONArray(rows)))
        return res
    }

    // ------------------------------------------------------------------ characters
    private fun convertCharacters() {
        val cdir = File(root, "data/characters")
        for (cid in chars.keys.toList()) {
            val p = File(cdir, "$cid.json")
            if (!p.isFile) { w("character \"$cid\" is a base-game character (not inside the mod); Psych uses its own \"$cid\" if it exists"); continue }
            chars[cid] = try { convertCharacter(cid, jload(p)) } catch (e: Exception) { w("character $cid failed: ${e.message}"); null }
        }
    }

    private fun iconColor(iconId: String): JSONArray {
        val p = findAsset("icons/icon-$iconId") ?: findAsset("icons/$iconId")
        if (p != null) {
            val src = BitmapFactory.decodeFile(p.path)
            if (src != null) {
                val w0 = if (src.width >= src.height * 2) src.width / 2 else src.width
                val crop = Bitmap.createBitmap(src, 0, 0, max(1, w0), src.height)
                val im = Bitmap.createScaledBitmap(crop, 32, 32, true)
                val px = ArrayList<IntArray>(); val hsv = FloatArray(3)
                for (y in 0 until 32) for (x in 0 until 32) { val c = im.getPixel(x, y); if (Color.alpha(c) > 200) px.add(intArrayOf(Color.red(c), Color.green(c), Color.blue(c))) }
                if (px.isNotEmpty()) {
                    fun score(q: IntArray): Float { Color.RGBToHSV(q[0], q[1], q[2], hsv); return hsv[1] * 0.6f + hsv[2] * 0.4f }
                    val best = px.maxByOrNull { score(it) }!!
                    val near = px.filter { abs(it[0] - best[0]) + abs(it[1] - best[1]) + abs(it[2] - best[2]) < 90 }.ifEmpty { listOf(best) }
                    return JSONArray().put(near.sumOf { it[0] } / near.size).put(near.sumOf { it[1] } / near.size).put(near.sumOf { it[2] } / near.size)
                }
            }
        }
        val fb = methods.o("healthbar_fallback")
        return fb.optJSONArray(iconId) ?: fb.a("default")
    }

    private fun convertCharacter(cid: String, d: JSONObject): CharInfo? {
        val rt = d.s("renderType", "sparrow")
        val asset = d.s("assetPath", "characters/$cid").substringAfterLast(':')
        val animsIn = d.a("animations").objs()
        var image = "characters/" + asset.substringAfterLast('/')
        val atlasDir = if (rt in listOf("animateatlas", "atlas")) findAssetDir(asset) else null
        var xmlFiles: List<File> = emptyList()
        if (rt in listOf("animateatlas", "atlas") || atlasDir != null) {
            if (atlasDir == null || !File(atlasDir, "Animation.json").isFile) { w("character $cid: atlas folder missing"); return null }
            val reader = Atlas.SpriteMapReader(atlasDir)
            if (reader.placeholder || reader.sprites.isEmpty()) {
                w("character \"$cid\": its spritemap image is a 1x1 placeholder (the real art is in the base game) -> character dropped, slot hidden")
                m("stripped atlas detected -> girlfriend/slot hidden instead of broken sprite")
                emptyChars.add(cid); reader.recycle()
                return CharInfo(null, 2, doubleArrayOf(0.0, 0.0), cid, true)
            }
            val groups = ArrayList<Atlas.Group>(); val seen = HashSet<String>()
            for (a in animsIn) {
                val pre = a.s("prefix")
                if (!seen.add(pre.lowercase())) continue
                val r = reader.renderLabel(pre)
                if (r == null) { w("character $cid: label \"$pre\" not found in the atlas"); continue }
                groups.add(Atlas.Group(pre, r.frames))
            }
            val sheets = Atlas.packSparrow(groups, P("images", "characters"), cid)   // <= 2048 px per sheet, extra sheets cid_2, cid_3 ...
            groups.forEach { g -> g.frames.forEach { it.recycle() } }; reader.recycle()
            image = sheets.joinToString(",") { "characters/$it" }; xmlFiles = sheets.map { P("images", "characters", "$it.xml") }
            if (sheets.size > 1) m("big character art cut into ${sheets.size} sheets (<= 2048 px) linked through a comma separated image field")
            m("spritemap (Adobe Animate atlas) -> rendered with the main atlas engine -> Sparrow sheet + xml")
        } else {
            val xmlFile = findAsset(asset, ".xml"); val png = findAsset(asset, ".png")
            if (png == null || xmlFile == null) { w("character $cid: image/xml \"$asset\" not found"); return null }
            val base = asset.substringAfterLast('/')
            png.copyTo(P("images", "characters", "$base.png").also { it.parentFile?.mkdirs() }, overwrite = true)
            xmlFile.copyTo(P("images", "characters", "$base.xml"), overwrite = true)
            xmlFiles = listOf(P("images", "characters", "$base.xml"))
            if (rt == "multisparrow") w("character $cid: multisparrow has extra sheets that are not merged yet")
        }
        val scale = d.d("scale", 1.0)
        val iconId = d.optJSONObject("healthIcon")?.s("id", cid) ?: cid
        val anims = JSONArray()
        for (a in animsIn) {
            val off = a.optJSONArray("offsets") ?: JSONArray("[0,0]")
            anims.put(JSONObject().put("anim", a.s("name")).put("name", a.s("prefix")).put("fps", a.d("frameRate", 24.0).toInt()).put("loop", a.b("looped"))
                .put("indices", a.optJSONArray("frameIndices") ?: JSONArray()).put("offsets", JSONArray().put(-off.dbl(0)).put(-off.dbl(1))))
        }
        val idle = animsIn.firstOrNull { it.s("name") in listOf("idle", "danceLeft") } ?: animsIn.firstOrNull()
        val fs = if (idle != null) Atlas.sparrowFirstFrameSize(xmlFiles, idle.s("prefix")) else null
        charSizes[cid] = if (fs != null) doubleArrayOf(fs.first * scale, fs.second * scale) else doubleArrayOf(0.0, 0.0)
        val offs = d.optJSONArray("offsets") ?: JSONArray("[0,0]"); val camOff = d.optJSONArray("cameraOffsets") ?: JSONArray("[0,0]")
        val psych = JSONObject().put("animations", anims).put("vocals_file", "").put("no_antialiasing", d.b("isPixel")).put("image", image)
            .put("position", JSONArray().put(offs.dbl(0)).put(offs.dbl(1))).put("healthicon", iconId).put("flip_x", d.b("flipX"))
            .put("healthbar_colors", iconColor(iconId)).put("camera_position", JSONArray().put(camOff.dbl(0)).put(camOff.dbl(1)))
            .put("sing_duration", d.d("singTime", 4.0)).put("scale", scale)
        jsave(P("characters", "$cid.json"), psych)
        m("character json: V-Slice anim offsets negated -> Psych offsets; position=offsets; flipX kept; healthbar colour measured from the icon")
        return CharInfo(psych, d.d("danceEvery", 2.0).toInt(), doubleArrayOf(camOff.dbl(0), camOff.dbl(1)), iconId, false)
    }

    // ------------------------------------------------------------------ stages
    private fun metadataFiles(): List<File> = File(root, "data/songs").listFiles { f -> f.isDirectory }?.sortedBy { it.name }?.flatMap { dir ->
        dir.listFiles { f -> f.name.contains("-metadata") && f.name.endsWith(".json") }?.sortedBy { it.name } ?: emptyList() } ?: emptyList()

    private fun convertStages() {
        val used = sortedSetOf<String>()
        for (f in metadataFiles()) used.add(jload(f).o("playData").s("stage", "mainStage"))
        for (sid in used) {
            val p = File(root, "data/stages/$sid.json")
            if (!p.isFile) { w("stage \"$sid\" is a base-game stage (not in the mod)"); continue }
            convertStage(sid, jload(p))
        }
        val usedEv = HashSet<String>()
        File(root, "data/songs").listFiles { f -> f.isDirectory }?.forEach { dir ->
            dir.listFiles { f -> f.name.contains("-chart") && f.name.endsWith(".json") }?.forEach { f -> jload(f).a("events").objs().forEach { usedEv.add(it.s("e")) } }
        }
        val evDir = File(root, "scripts/events")
        evDir.listFiles { f -> f.name.endsWith(".hxc") }?.sortedBy { it.name }?.forEach { h ->
            val kind = Regex("super\\(\\s*\"([^\"]+)\"").find(h.readText())?.groupValues?.get(1) ?: h.nameWithoutExtension
            if (kind !in usedEv) dropped.add(h.name) else if (!evMap.has(kind)) hxFiles.add(Hx2Lua.HxFile(h, "event", kind))
        }
        if (dropped.isNotEmpty()) w("${dropped.size} custom event scripts are not used by any chart, so they were not ported: ${dropped.joinToString(", ")}")
        val stageFiles = File(root, "scripts/stages").listFiles { f -> f.name.endsWith(".hxc") }?.sortedBy { it.name } ?: emptyList()
        stageFiles.forEach { hxFiles.add(Hx2Lua.HxFile(it, "stage", null)) }
        // every other Haxe script of the mod (modules, song scripts, characters) is converted too
        val seen = hxFiles.map { it.path }.toSet()
        File(root, "scripts").walkTopDown().filter { it.isFile && it.extension.startsWith("hx") }.sortedBy { it.path }.forEach { h ->
            if (h in seen || h.parentFile == evDir || h.parentFile?.name == "stages") return@forEach
            hxFiles.add(Hx2Lua.HxFile(h, "script", null))
        }
    }

    /** Hx source (any .hx/.hxc in the mod) whose file name matches [kind], for the Brain to read. */
    private fun hxSourceFor(kind: String): String? = try {
        File(root, "scripts").walkTopDown().firstOrNull { it.isFile && it.extension.startsWith("hx") && Library.similarity(it.nameWithoutExtension, kind) >= 0.9 }?.readText()
    } catch (_: Exception) { null }

    /** Events / note kinds that have no mapping and no translated script: library (exact, then closest), else Brain builds one. */
    private fun writeMissingScripts() {
        for (kind in unmappedEvents) {
            val dest = P("custom_events", "$kind.lua"); if (dest.isFile) continue
            val exact = Library.event(ctx, kind)
            val near = if (exact == null) Library.nearest(ctx, "events", kind) else null
            val (src, how) = when {
                exact != null -> exact to "ready-made library script"
                near != null -> near.first to "closest library script \"${near.second}\""
                else -> Brain.synthEvent(kind, hxSourceFor(kind), evSamples[kind], modShaders).let { it.first to "built by Brain (${it.second})" }
            }
            dest.parentFile?.mkdirs(); dest.writeText(src); m("event $kind -> $how")
        }
        for (kind in unknownKinds) {
            val dest = P("custom_notetypes", "$kind.lua"); if (dest.isFile) continue
            val exact = Library.noteType(ctx, kind)
            val near = if (exact == null) Library.nearest(ctx, "notetypes", kind) else null
            val (src, how) = when {
                exact != null -> exact to "ready-made library script"
                near != null -> near.first to "closest library script \"${near.second}\""
                else -> Brain.synthNote(kind, hxSourceFor(kind), usageOf(kind)).let { it.first to "built by Brain (${it.second})" }
            }
            dest.parentFile?.mkdirs(); dest.writeText(src); m("note kind $kind -> custom_notetypes/$kind.lua: $how")
        }
    }

    private fun convertScripts() {
        if (hxFiles.isEmpty()) return
        val (nOk, fails) = hx.convertMany(hxFiles, out, File(outRoot, "${slugName}_unconverted"))
        m("haxe scripts -> lua (per function, rule table in methods.json): $nOk file(s) converted")
        // ready-made library script for an event that could not be translated (same name)
        val provided = HashSet<String>()
        for (hf in hxFiles.filter { it.kind == "event" }) {
            val kind = hf.event ?: hf.path.nameWithoutExtension
            val dest = File(out, "custom_events/$kind.lua")
            if (dest.isFile) continue
            if (fails.none { it.file == hf.path.name }) continue
            val exact = Library.event(ctx, kind)
            val near = if (exact == null) Library.nearest(ctx, "events", kind) else null
            val (src, how) = when {
                exact != null -> exact to "ready-made library script"
                near != null -> near.first to "closest library script \"${near.second}\""
                else -> Brain.synthEvent(kind, try { hf.path.readText() } catch (_: Exception) { null }, evSamples[kind], modShaders).let { it.first to "built by Brain (${it.second})" }
            }
            dest.parentFile?.mkdirs(); dest.writeText(src); provided.add(hf.path.name)
            m("event $kind -> $how (custom_events/$kind.lua)")
        }
        for (f in fails) if (f.file !in provided) w("could not convert ${f.file} :: ${f.fn} (${f.why}) -> see ${slugName}_unconverted/")
    }

    private fun convertStage(sid: String, d: JSONObject) {
        val zoom = d.d("cameraZoom", 1.0)
        val chs = d.o("characters")
        val slotNames = listOf("bf" to "boyfriend", "dad" to "dad", "gf" to "gf")
        var slotChar = mapOf<String, String?>()
        for (f in metadataFiles()) {
            val pd = jload(f).o("playData")
            if (pd.s("stage") == sid) { val c = pd.o("characters"); slotChar = mapOf("bf" to c.s("player").ifEmpty { null }, "dad" to c.s("opponent").ifEmpty { null }, "gf" to c.s("girlfriend").ifEmpty { null }); break }
        }
        fun topLeft(slot: String): JSONArray {
            val c = chs.o(slot); val pos = c.optJSONArray("position") ?: JSONArray("[0,0]")
            val sz = slotChar[slot]?.let { charSizes[it] } ?: doubleArrayOf(0.0, 0.0)
            return JSONArray().put(Math.round((pos.dbl(0) - sz[0] / 2) * 100) / 100.0).put(Math.round((pos.dbl(1) - sz[1]) * 100) / 100.0)
        }
        val gfId = slotChar["gf"]; val hideGf = gfId == null || gfId in emptyChars
        val slotData = LinkedHashMap<String, DoubleArray>()
        for ((slot, name) in slotNames) {
            val c = chs.o(slot); val cam = c.optJSONArray("cameraOffsets") ?: JSONArray("[0,0]")
            val info = slotChar[slot]?.let { chars[it] }
            val cc = info?.cam ?: doubleArrayOf(0.0, 0.0)
            slotData[name] = doubleArrayOf(cam.dbl(0) + cc[0], cam.dbl(1) + cc[1], (info?.dance ?: 2).toDouble())
        }
        jsave(P("stages", "$sid.json"), JSONObject().put("directory", "").put("stageUI", "normal").put("defaultZoom", zoom).put("isPixelStage", false).put("boyfriend", topLeft("bf"))
            .put("girlfriend", topLeft("gf")).put("opponent", topLeft("dad")).put("hide_girlfriend", hideGf).put("camera_boyfriend", JSONArray("[0,0]"))
            .put("camera_opponent", JSONArray("[0,0]")).put("camera_girlfriend", JSONArray("[0,0]")).put("camera_speed", 1))
        m("stage json: V-Slice character position is the feet/bottom-centre -> Psych top-left (minus half width, minus height of the idle frame)")
        // ---- lua: props
        val props = d.a("props").objs()
        val lines = ArrayList<String>(); lines.add("-- PortYou Studio: stage \"$sid\" (generated from V-Slice stage json)"); lines.add("function onCreate()")
        val zs = chs.keys().asSequence().map { chs.o(it).d("zIndex", 0.0) }.sorted().toList().ifEmpty { listOf(0.0) }
        val pending = ArrayList<Pair<String, Double>>()
        for ((i, p) in props.withIndex().sortedBy { it.value.d("zIndex", 0.0) }) {
            val tag = "p$i"; val img = p.s("assetPath").substringAfterLast(':')
            if (img.isEmpty()) continue
            if (findAsset(img) == null) {
                w("stage prop image \"$img\" is missing (also in the original mod) - a plain colour block was used so the stage is not black")
                if (p.a("animations").length() == 0) {
                    val pp = p.optJSONArray("position") ?: JSONArray("[0,0]"); val sA = p.optJSONArray("scale")
                    val sx = if (sA != null) sA.dbl(0, 1.0) else p.d("scale", 1.0)
                    lines.add("\tmakeLuaSprite(${lua(tag)}, nil, ${ns(pp.opt(0))}, ${ns(pp.opt(1))})")
                    lines.add("\tmakeGraphic(${lua(tag)}, 1280, 720, '30344A')")
                    if (sx != 1.0) lines.add("\tscaleObject(${lua(tag)}, ${ns(sx)}, ${ns(sx)}, true)")
                    lines.add("\taddLuaSprite(${lua(tag)}, false)")
                }
                continue
            }
            val anims = p.a("animations").objs(); val pos = p.optJSONArray("position") ?: JSONArray("[0,0]")
            if (anims.isNotEmpty()) {
                lines.add("\tmakeAnimatedLuaSprite(${lua(tag)}, ${lua(img)}, ${ns(pos.opt(0))}, ${ns(pos.opt(1))})")
                for (a in anims) {
                    val fr = a.a("frameIndices")
                    if (fr.length() > 0) lines.add("\taddAnimationByIndices(${lua(tag)}, ${lua(a.s("name"))}, ${lua(a.s("prefix"))}, '${(0 until fr.length()).joinToString(",") { ns(fr.opt(it)) }}', ${ns(a.d("frameRate", 24.0))})")
                    else lines.add("\taddAnimationByPrefix(${lua(tag)}, ${lua(a.s("name"))}, ${lua(a.s("prefix"))}, ${ns(a.d("frameRate", 24.0))}, ${if (a.b("looped")) "true" else "false"})")
                }
                if (p.s("startingAnimation").isNotEmpty()) lines.add("\tplayAnim(${lua(tag)}, ${lua(p.s("startingAnimation"))}, true)")
            } else lines.add("\tmakeLuaSprite(${lua(tag)}, ${lua(img)}, ${ns(pos.opt(0))}, ${ns(pos.opt(1))})")
            // V-Slice "scale" is either a number (1.75) or an array [x, y] - the number form used to be ignored (tiny / black backgrounds)
            val scA = p.optJSONArray("scale")
            val scX = if (scA != null) scA.dbl(0, 1.0) else p.d("scale", 1.0)
            val scY = if (scA != null) scA.dbl(1, scX) else scX
            if (!(scX == 1.0 && scY == 1.0)) lines.add("\tscaleObject(${lua(tag)}, ${ns(scX)}, ${ns(scY)}, true)")
            val scr = p.optJSONArray("scroll") ?: JSONArray("[1,1]")
            lines.add("\tsetScrollFactor(${lua(tag)}, ${ns(scr.opt(0))}, ${ns(scr.opt(1))})")
            if (p.d("alpha", 1.0) != 1.0) lines.add("\tsetProperty(${lua(tag)}..'.alpha', ${ns(p.d("alpha", 1.0))})")
            if (p.d("angle", 0.0) != 0.0) lines.add("\tsetProperty(${lua(tag)}..'.angle', ${ns(p.d("angle", 0.0))})")
            if (p.b("flipX")) lines.add("\tsetProperty(${lua(tag)}..'.flipX', true)")
            if (p.b("flipY")) lines.add("\tsetProperty(${lua(tag)}..'.flipY', true)")
            val col = p.s("color", "#FFFFFF").ifEmpty { "#FFFFFF" }.trimStart('#').takeLast(6)
            if (col.uppercase() != "FFFFFF") lines.add("\tsetProperty(${lua(tag)}..'.color', getColorFromHex(${lua(col)}))")
            if (p.s("blend").isNotEmpty()) lines.add("\tsetBlendMode(${lua(tag)}, ${lua(p.s("blend").lowercase())})")
            if (p.b("isPixel")) lines.add("\tsetProperty(${lua(tag)}..'.antialiasing', false)")
            val z = p.d("zIndex", 0.0)
            lines.add("\taddLuaSprite(${lua(tag)}, ${if (z > zs.max()) "true" else "false"})")
            if (z >= zs.min() && z <= zs.max()) pending.add(tag to z)
        }
        lines.add("end")
        if (pending.isNotEmpty()) {
            lines.add("function onCreatePost()")
            val order = listOf("gfGroup" to chs.o("gf").d("zIndex", 100.0), "dadGroup" to chs.o("dad").d("zIndex", 200.0), "boyfriendGroup" to chs.o("bf").d("zIndex", 300.0)).sortedBy { it.second }
            for ((tag, z) in pending) order.firstOrNull { it.second > z }?.let { lines.add("\tsetObjectOrder(${lua(tag)}, getObjectOrder(${lua(it.first)}))") }
            lines.add("end")
        }
        val dance = props.withIndex().filter { it.value.a("animations").length() > 0 && it.value.d("danceEvery", 0.0) != 0.0 }
        if (dance.isNotEmpty()) {
            lines.add("function onBeatHit()")
            for ((i, p) in dance) {
                val tag = "p$i"; val names = p.a("animations").objs().map { it.s("name") }; val de = p.d("danceEvery", 1.0).toInt().coerceAtLeast(1)
                if ("danceLeft" in names && "danceRight" in names) lines.add("\tif curBeat % $de == 0 then playAnim(${lua(tag)}, (curBeat / $de) % 2 == 0 and 'danceLeft' or 'danceRight', true) end")
                else lines.add("\tif curBeat % $de == 0 then playAnim(${lua(tag)}, ${lua(names[0])}, true) end")
            }
            lines.add("end")
        }
        P("stages", "$sid.lua").also { it.parentFile?.mkdirs() }.writeText(lines.joinToString("\n") + "\n")
        m("stage props -> Lua sprites (position, scale, scroll, alpha, colour, blend, flip, animations, dance); z-index -> behind/front of the characters")
        writeRuntime(slotData, zoom)
    }

    private fun writeRuntime(slot: Map<String, DoubleArray>, zoom: Double) {
        val pal = methods.a("extra_events_palette").strs().joinToString(", ") { "'$it'" }
        val data = "local STAGE_ZOOM = ${ns(zoom)}\nlocal PALETTE = {$pal}\nlocal SLOT = {\n" +
            slot.entries.joinToString("") { "\t${it.key} = {cx = ${ns(it.value[0])}, cy = ${ns(it.value[1])}, dance = ${ns(it.value[2])}},\n" } + "}\n"
        val tpl = ctx.assets.open("converter/vslice_runtime.lua").bufferedReader().readText().replace("--[[DATA]]", data)
        P("scripts", "portyou_vslice.lua").also { it.parentFile?.mkdirs() }.writeText(tpl)
    }

    // ------------------------------------------------------------------ remaining assets
    private fun copyRemainingAssets() {
        val skip = methods.a("skip_dirs").strs().toSet()
        val atlasDirs = ArrayList<File>()
        for (d in imageDirs) if (d.isDirectory) d.walkTopDown().filter { it.isFile && it.name == "Animation.json" }.forEach { atlasDirs.add(it.parentFile!!) }
        for (d in imageDirs) {
            if (!d.isDirectory) continue
            d.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(d).path
                val top = rel.substringBefore('/')
                if (top in skip && rel.contains('/')) return@forEach
                if (atlasDirs.any { f.path.startsWith(it.path + File.separator) }) return@forEach
                val dst = P("images", rel)
                if (dst.isFile) return@forEach
                dst.parentFile?.mkdirs(); f.copyTo(dst)
            }
        }
        for (sub in listOf("sounds", "music", "videos")) for (base in listOf(File(root, sub), File(root, "shared/$sub")))
            if (base.isDirectory) base.copyRecursively(P(sub), overwrite = true)
        m("assets: images/ + shared/images/ merged into Psych images/ (freeplay pixel icons and story-menu art are dropped/converted separately)")
    }

    // ------------------------------------------------------------------ weeks
    private fun writeWeeks(songs: List<SongInfo>) {
        val levels = File(root, "data/levels").listFiles { f -> f.name.endsWith(".json") }?.sortedBy { it.name }?.map { jload(it) } ?: emptyList()
        val story = levels.firstOrNull { it.b("visible", true) && storyAssetsOk(it) }
        val rows = JSONArray()
        for (s in songs) for (pid in s.psychIds.ifEmpty { listOf(s.id) }) {
            val op = oppOf(s); val ci = if (op != null) chars[op] else null
            rows.put(JSONArray().put(pid).put(firstIcon(s)).put(ci?.psych?.optJSONArray("healthbar_colors") ?: JSONArray("[161,161,161]")))
        }
        val diffs = LinkedHashSet<String>(); songs.forEach { diffs.addAll(it.diffs) }
        val week = JSONObject().put("songs", rows).put("weekCharacters", JSONArray("[\"\",\"bf\",\"gf\"]")).put("weekBackground", "").put("weekBefore", "tutorial")
            .put("storyName", title).put("weekName", title).put("startUnlocked", true).put("hideStoryMode", true).put("hideFreeplay", false)
            .put("difficulties", diffs.joinToString(", ").ifEmpty { "Normal" })
        if (story != null) convertStory(story, week) else m("week: freeplay only (no usable classic story assets; custom story UI is deleted)")
        jsave(P("weeks", "$slugName.json"), week)
        m("week file named after the mod ($slugName.json) so two mods never collide")
    }

    private fun storyAssetsOk(lv: JSONObject): Boolean {
        val props = lv.a("props").objs(); if (props.isEmpty()) return false
        return props.all { it.s("assetPath").isEmpty() || findAsset(it.s("assetPath")) != null }
    }

    private fun convertStory(lv: JSONObject, week: JSONObject) {
        val names = arrayOf("", "bf", "gf")
        for ((i, p) in lv.a("props").objs().take(3).withIndex()) {
            val slotId = "$slugName-" + listOf("dad", "bf", "gf")[i]
            val src = p.s("assetPath"); val png = findAsset(src) ?: continue; val xml = findAsset(src, ".xml")
            val dst = P("images", "menucharacters", slotId); dst.parentFile?.mkdirs()
            png.copyTo(File(dst.path + ".png"), overwrite = true); xml?.copyTo(File(dst.path + ".xml"), overwrite = true)
            val anims = p.a("animations").objs().ifEmpty { listOf(JSONObject()) }
            val idle = anims.firstOrNull { it.s("name") in listOf("idle", "danceLeft") } ?: anims[0]
            val conf = anims.firstOrNull { it.s("name") == "confirm" }
            val off = p.optJSONArray("offsets") ?: JSONArray("[0,0]")
            jsave(P("images", "menucharacters", "$slotId.json"), JSONObject().put("image", "menucharacters/$slotId").put("scale", p.d("scale", 1.0))
                .put("position", JSONArray().put(off.dbl(0)).put(off.dbl(1))).put("idle_anim", idle.s("prefix", "idle"))
                .put("confirm_anim", (conf ?: idle).s("prefix", idle.s("prefix", "idle"))).put("flipX", false))
            names[i] = slotId
        }
        week.put("weekCharacters", JSONArray(names.toList())).put("hideStoryMode", false).put("storyName", lv.s("name", title))
        val bg = lv.opt("background")
        if (bg is String && bg.startsWith("#") && bg.length >= 7) {
            val bmp = Bitmap.createBitmap(1280, 400, Bitmap.Config.ARGB_8888); bmp.eraseColor(Color.rgb(bg.substring(1, 3).toInt(16), bg.substring(3, 5).toInt(16), bg.substring(5, 7).toInt(16)))
            P("images", "menubackgrounds", "menu_$slugName.png").also { it.parentFile?.mkdirs() }.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            week.put("weekBackground", slugName)
        }
        val tp = lv.s("titleAsset").takeIf { it.isNotEmpty() }?.let { findAsset(it) }
        if (tp != null) tp.copyTo(P("images", "storymenu", "$slugName.png").also { it.parentFile?.mkdirs() }, overwrite = true)
        m("story mode: classic story assets found -> menucharacters + week image + background colour PNG")
    }

    private fun oppOf(s: SongInfo): String? {
        val f = File(root, "data/songs/${s.id}").listFiles { x -> x.name.endsWith("-metadata.json") }?.sortedBy { it.name }?.firstOrNull() ?: return null
        return jload(f).o("playData").o("characters").optString("opponent", "").ifEmpty { null }
    }
    private fun firstIcon(s: SongInfo): String { val op = oppOf(s) ?: return "face"; val c = chars[op]; return if (c != null && !c.empty) c.icon else op }

    private fun writeReport() {
        val txt = listOf("# PortYou Studio - conversion report", "", "Mod: $title (author in meta: ${meta.s("author", "?")})", "", "## Methods used", "") +
            rMethods.map { "- $it" } + listOf("", "## Warnings / things for the mod owner", "") + rWarn.map { "- $it" } + listOf("")
        P("CONVERSION_REPORT.md").writeText(txt.joinToString("\n"))
    }
}
