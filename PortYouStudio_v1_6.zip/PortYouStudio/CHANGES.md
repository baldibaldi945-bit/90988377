# PortYou Studio - build 1.6 (Brain v2 + library from the real script collection)

The "all scripts" zip (4,193 files: 246 stage scripts, 422 events, 113 note types, 183 global scripts, 587 song scripts, 431 charts) was read this round.

1. **Brain v2** (`Brain.kt`, reference + corpus test in `tools/portyou/brain.py`): works out what an unknown event / note kind does from, in this order, (a) the original source: real API calls and their literal values (keys it listens for, durations, damage), (b) how the charts USE it: value shapes of every event row (colour, bool+character, comma lists, sentences, json) and the side / count of every note, (c) the name: English + Spanish + Portuguese words, also glued names (`slowzoom`, `multsv`). Tested on all 449 kinds used by the 431 charts: every generated Lua is block-balanced.
   New understood behaviours: screen effects (Bloom / Saturation / Vignette ... use the mod's own `.frag` on camGame, on/off from value1), stage zoom (`Change Stage Zoom`, `Camera Zoom Adjust`), bop interval / strength (`Camera Bump Modulo`, `Set Camera Bopping`), `HScript Call` -> `callOnLuas(function, arg)`, video events, cinematic bars, extra characters singing (`opponent4`, `plr3`, `Third Player Note`, `Both Sing`), a character animation named like the kind (`singUP-ugh`) becomes the note's anim suffix, opponent-only kinds are never made damaging.
   Honest fallback: a kind with no evidence gets a safe stub that prints one line, never a wrong guess.
2. **V-Slice converter** now hands the Brain the chart usage (event values, note side / count / sustains) and the mod's shader list.
3. **Library**: +9 events (incl. `SpaceBarNote` - the 5th Space lane with touch button, `Toggle Mechanic`, `GF Play Animation` ...), +1 note type, and a new `scripts` group (bf mechanic, health drain, HealthPullProtect, hold fixes, Stage Change Manager, window change ...) with `Library.script()`.

Not done yet in this build: wiring the `scripts` group into the converters automatically, stage-script reading (246 stages), Brain for Funky Maker custom notes, Kotlin compile (no compiler here - first CI build still pending).

---
# PortYou Studio - build 1.5 (from the real JOJO_N_Pico FNMM mod)

1. **Picker bug**: the V-Slice button refused `.fnmm` (and the extension list differed per button). Both buttons now accept zip / 7z / rar / fnmm and route by the detected mod type.
2. **Funky Maker note props were ignored**: every note carries `props {skin, onPressEvent, onMissEvent}`. Now: skin >= 2 with no action -> Psych `Hurt Note`; any note with an action pack on press/miss -> `custom_notetypes/fnmm-s<skin>-p<pack>-m<pack>.lua` that fires the pack's actions through `triggerEvent` (handled by `fnmm_runtime.lua`). The report lists the counts. (In JOJO: 31 player notes with skin 2.)
3. **Brain** learned more mechanics: jump / fly, move & return, dodge window on SPACE (`keyJustPressed`), extra lives (`onGameOver`), icon change, show / hide object.
4. Stage json of both converters now has `"stageUI": "normal"` (guard against the `cacheCountdown` / `StringMap.set` crash in the supplied log).

Note: the supplied "all scripts" zip only held 6 crash logs, `CREDITS_stuff.lua` and one chart json - no stage / mechanic scripts - so nothing new could be learned from it beyond the crash logs.

---
# PortYou Studio - build 1.4

1. **Big sprites (V-Slice + Funky Maker)**: Animate/spritemap characters are packed into sheets of at most 2048 px; extra frames go to `<name>_2`, `<name>_3` ... linked through the comma separated `image` of the character json. Already-made Sparrow sheets bigger than 2048 px (`ImagePost`, `Atlas.splitSparrow`) are cut the same way, every `SubTexture` attribute kept.
2. **Lossless PNG compression** (`ImageOpt.kt`, optipng-style, same goal as compress2go): indexed PNG + tRNS when <= 256 colours, RGB when nothing is transparent, invisible pixels zeroed, best row filter + Deflate 9. Pixels are never changed, so no blotches and no white/black background. Runs on every image of the finished mod; the size saving is written to PORTYOU_REPORT.txt. (Verified with a Python port against Pillow on 1/2/4/8-bit palette, RGB and RGBA.)
3. **Brain** (`Brain.kt` + `Library.nearest`): an event / note kind with no mapping and no translated Haxe is now (a) matched against the 406 events / 111 note types by words + fuzzy ratio, (b) otherwise built from its name and Haxe source (flash, shake, zoom, fade, alpha, anim, hey, follow, speed, char, angle, text, sound; harmful / healing / alt / no-anim notes). Every generated line is wrapped in pcall.
5. **Note types**: unknown V-Slice note kinds now get `custom_notetypes/<kind>.lua` (library, closest library script, or Brain).
7. Funky Maker: mod detection walks up to 6 folders deep (any folder with data.json + scene.json), `events.json` is optional, BOM-safe json reading, unknown archive magic falls back to zip.

Not done in this build: item 4 (bigger script library - the source scripts were not in this zip), item 6 (the odd arrow positions - needs the screenshot/mod), Python tools mirror (`tools/`) of the new code.

---
# PortYou Studio - build 1.3 (fixes from the Nov 20 test mods)

1. **Funky Maker converter was broken**: new `.FNMM` files (scene.json v4) store positions in `transform[0].position{x,y}` and cameras as `position{x,y}`; the old code read flat `x`/`y` and crashed. Both layouts are read now. Either picker accepts either mod type (routing is by detected type). The real crash text is saved to `cache/last_error.txt`.
2. **Big sprites**: Funky Maker character strips are cut into several atlases (max 2048 px each, weak-phone/GPU safe) and linked through a comma separated `image` (`characters/x,characters/x_2`).
3. **Black screen in V-Slice ports**: stage props with a numeric `scale` (1.75) were not scaled at all; a prop image that is missing (even in the original mod) now becomes a colour block instead of an empty black stage.
4. **"Error on lua script!"** (`'then' expected near '?'`, `'<name>' expected near "v1"`): Haxe `?.`, ternaries, `{ name: v }` literals, object-method calls and capitalised engine classes are now refused (function reported, never written). Every converted callback runs inside `pcall`, `getEventSchema/getTitle` are dropped, `super.*()` calls are removed.
5. **Library**: `library.json.gz` (406 events, 111 note types, from the supplied collection) + new Haxe->Lua rules (Std.*, FlxG.sound, camFollow, Paths.*). FlashWhite and Drunk now work through runtime events.
6. **Mod name** = the original archive/folder name (meta title only as the last fallback).
7. **Akram**: 11 new sayings in all 6 languages (last one shows the fail icon on the bubble), text moved down/right, "يا زول" -> "يا زم".

---
# PortYou Studio — what changed in this build

1. **Charts (V-Slice + Funky Maker)**: Psych 1.0 `psych_v1` charts use ABSOLUTE lanes (0-3 player, 4-7 opponent); `mustHitSection` only moves the camera. The old converter flipped lanes inside every "opponent" section, which swapped player/opponent arrows. Fixed. GF arrows are written with the `GF Sing` note type (FNMM strumLine 2+, V-Slice note kind `gf`).
2. **Funky Maker "Null Object Reference" in `PlayState.generateSong`**: the chart had no `events` key. Events are now stored inside the chart (no separate events.json).
3. **Black screen / wrong screen**: runtime scripts rewritten defensively (colour parsing never falls back to black, zoom/alpha clamped, every event wrapped in pcall, camera starts on a defined point, FNMM objects are layered relative to the real character index, FNMM zoom uses the same 0.7 factor as the stage).
4. **Haxe -> Lua** (`tools/portyou/hx2lua.py`): per-function, many files at once, rule table in `methods.json` ("haxe"), optional local AI (`PORTYOU_LLM_URL`). Anything not convertible is moved OUT of the mod into `<mod>_unconverted/` with `ماقدرت_احول_ذا_COULD_NOT_CONVERT.txt` (ar/en/pt/ja) — only created when something failed.
5. **Spritemaps**: smart label matching (exact / prefix / normalised / fuzzy / optional AI) between the mod's character json animation names and the Animate atlas labels.
6. **Credits**: every converted mod gets `scripts/portyou_credit.lua` (the supplied text.lua with "Port You Studio") besides pack.json/pack.png.

7. **Kotlin V-Slice port** (this build): `Atlas.kt` (Animate spritemap reader + Sparrow packer on Android Canvas/Matrix, no Pillow), `Hx2Lua.kt` (same per-function rules as `hx2lua.py`, reads `assets/converter/methods.json`), `VSliceConverter.kt` (charts, events, characters, stages, weeks, credits, report), so V-Slice mods convert fully on the phone without Termux/Python.
8. **Vocal merging on the phone**: `AudioMerge.kt` uses `dev.ffmpegkit-maintained:ffmpeg-kit-audio:6.0.3` (libvorbis, `amix=normalize=0`). Needs minSdk 24 and arm64 only (that is all the maintained fork publishes). If ffmpeg fails the first vocal file is used and a warning is written to the report.
9. `<mod>_unconverted/` (Haxe the converter could not translate) is now also copied to the save folder.
10. **ASTC textures -> PNG** (`Astc.kt`): pure-Kotlin ASTC LDR decoder (all 2D block sizes 4x4..12x12, dual-plane, 1-4 partitions, void-extent, CEM 0/1/4/5/6/8/9/10/12/13) for raw `.astc` and KTX1 files. Detected by file header (not extension), run right after extraction, streamed to PNG row by row (low RAM). Failures go to `PORTYOU_REPORT.txt` and the original file is kept. HDR endpoints = magenta; KTX2 / 3D not supported.
