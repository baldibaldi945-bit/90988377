"""Haxe (.hx / .hxc, V-Slice & Psych HScript style) -> Psych Engine Lua.

Works per FUNCTION, not per file: every function that converts cleanly is emitted; a function that contains something the
engine cannot translate with certainty is NOT guessed - it is left out and reported.  Several files can be converted at once
(convert_many).  Simple and complex code are both handled by the rule table in methods.json['haxe'] (add rules there, every
future conversion uses them) and, optionally, a local AI (portyou/ai.py) that is only asked for functions the rules failed on.
"""
import json, os, re
from . import ai as AI

HERE = os.path.dirname(os.path.abspath(__file__))
KB = json.load(open(os.path.join(HERE, 'methods.json'), encoding='utf-8')).get('haxe', {})

CALLBACKS = KB.get('callbacks', {})
API_RULES = [(re.compile(a), b) for a, b in KB.get('api_rules', [])]
UNSUPPORTED = [(re.compile(a), why) for a, why in KB.get('unsupported', [])]


class Unconvertible(Exception):
    pass


# ----------------------------------------------------------------------------- lexical helpers
def strip_comments(src):
    out, i, n, q = [], 0, len(src), None
    while i < n:
        c = src[i]
        if q:
            out.append(c)
            if c == '\\' and i + 1 < n:
                out.append(src[i + 1]); i += 2; continue
            if c == q:
                q = None
            i += 1; continue
        if c in '"\'':
            q = c; out.append(c); i += 1; continue
        if src.startswith('//', i):
            while i < n and src[i] != '\n':
                i += 1
            continue
        if src.startswith('/*', i):
            j = src.find('*/', i + 2)
            i = n if j < 0 else j + 2
            continue
        out.append(c); i += 1
    return ''.join(out)


def match_brace(src, i):
    """index of the brace closing the one at src[i]; strings are skipped."""
    d, q, n = 0, None, len(src)
    while i < n:
        c = src[i]
        if q:
            if c == '\\':
                i += 2; continue
            if c == q:
                q = None
        elif c in '"\'':
            q = c
        elif c == '{':
            d += 1
        elif c == '}':
            d -= 1
            if d == 0:
                return i
        i += 1
    raise Unconvertible('unbalanced braces')


def split_members(src):
    """top-level members of a class body / script: ('function', name, args, body) | ('var', text)."""
    src = strip_comments(src)
    m = re.search(r'\bclass\s+\w+[^{]*\{', src)
    body = src
    if m:
        end = match_brace(src, m.end() - 1)
        body = src[m.end():end]
    members, i = [], 0
    fre = re.compile(r'(?:(?:override|public|private|static|inline)\s+)*function\s+(\w+)\s*\(([^)]*)\)\s*(?::\s*[\w.<>]+)?\s*\{')
    while i < len(body):
        f = fre.search(body, i)
        v = re.search(r'(?:(?:public|private|static|inline)\s+)*(?:var|final)\s+[^;{]*;', body[i:])
        nxt_v = i + v.start() if v else None
        if f and (nxt_v is None or f.start() < nxt_v):
            end = match_brace(body, f.end() - 1)
            members.append(('function', f.group(1), f.group(2), body[f.end():end]))
            i = end + 1
        elif v:
            members.append(('var', v.group(0)))
            i = nxt_v + len(v.group(0))
        else:
            break
    return members


# ----------------------------------------------------------------------------- expression / statement conversion
def split_top(s, sep=','):
    out, d, q, cur = [], 0, None, ''
    for c in s:
        if q:
            cur += c
            if c == q:
                q = None
            continue
        if c in '"\'':
            q = c
        if c in '([{':
            d += 1
        elif c in ')]}':
            d -= 1
        if c == sep and d == 0:
            out.append(cur); cur = ''
        else:
            cur += c
    out.append(cur)
    return out


def conv_expr(e):
    e = e.strip()
    for rx, why in UNSUPPORTED:
        if rx.search(e):
            raise Unconvertible(why)
    # protect strings
    strs = []

    def keep(m):
        strs.append(m.group(0)); return '\x00%d\x00' % (len(strs) - 1)
    e = re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', keep, e)
    for rx, rep in API_RULES:
        e = rx.sub(rep, e)
    e = re.sub(r'\bnull\b', 'nil', e)
    e = e.replace('!=', '~=').replace('&&', ' and ').replace('||', ' or ')
    e = re.sub(r'!(?!=)\s*', 'not ', e)
    e = re.sub(r'\bthis\.', '', e)
    e = re.sub(r':\s*(?:Int|Float|String|Bool|Dynamic|Array<\w+>)\b', '', e)
    e = re.sub(r'\bStd\.int\(([^()]*)\)', r'math.floor(\1)', e)
    e = re.sub(r'\bMath\.(floor|ceil|abs|sin|cos|sqrt|min|max|random|pow)\b', lambda m: 'math.' + m.group(1), e)
    e = re.sub(r'\bMath\.PI\b', 'math.pi', e)
    e = re.sub(r'\bMath\.round\(([^()]*)\)', r'math.floor((\1) + 0.5)', e)
    e = re.sub(r'\b(\w+)\.length\b', r'#\1', e)
    e = re.sub(r'\bmath\.pow\(([^,()]+),\s*([^()]+)\)', r'(\1 ^ \2)', e)
    # '+' with a string literal on either side is concatenation
    if '\x00' in e:
        e = re.sub(r'(\x00\d+\x00)\s*\+', r'\1 ..', e)
        e = re.sub(r'\+\s*(\x00\d+\x00)', r'.. \1', e)
        e = re.sub(r'\.\.\s*(\w[\w.\[\]()]*)\s*\+\s*(?=\x00|\w)', r'.. \1 .. ', e)
    e = re.sub(r'\[\s*\]', '{}', e) if re.fullmatch(r'\[\s*\]', e) else e
    if re.fullmatch(r'\[[^\]]*\]', e) and not re.search(r'\w\[', e):   # array literal
        e = '{' + e[1:-1] + '}'
    e = re.sub(r'\bforEach\b', 'forEach', e)
    for i, sx in enumerate(strs):
        e = e.replace('\x00%d\x00' % i, sx)
    left = re.search(r'\b(?:game|FlxG|Flx[A-Z]\w*|Paths|ClientPrefs|PlayState|Conductor)\.\w+', re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"", '', e))
    if left:
        raise Unconvertible('engine API without a Lua equivalent yet: ' + left.group(0))
    if '=>' in e or '->' in e or re.search(r'\bnew\s+\w', e):
        raise Unconvertible('lambda / constructor / map literal')
    return e.strip()


def conv_block(body, indent=1):
    out = []
    stmts = split_statements(body)
    for st in stmts:
        out += conv_stmt(st.strip(), indent)
    return out


def split_statements(body):
    """split on ';' and on top-level {...} blocks."""
    res, cur, d, q, i, n = [], '', 0, None, 0, len(body)
    while i < n:
        c = body[i]
        if q:
            cur += c
            if c == '\\' and i + 1 < n:
                cur += body[i + 1]; i += 2; continue
            if c == q:
                q = None
            i += 1; continue
        if c in '"\'':
            q = c; cur += c
        elif c in '([':
            d += 1; cur += c
        elif c in ')]':
            d -= 1; cur += c
        elif c == '{' and d == 0:
            end = match_brace(body, i)
            cur += body[i:end + 1]
            i = end + 1
            # keep 'else' attached to its if
            rest = body[i:].lstrip()
            if re.match(r'(else|catch)\b', rest):
                continue
            if cur.strip():
                res.append(cur)
            cur = ''
            continue
        elif c == ';' and d == 0:
            if cur.strip():
                res.append(cur)
            cur = ''
        else:
            cur += c
        i += 1
    if cur.strip():
        res.append(cur)
    return res


def head_and_block(st, kw):
    m = re.match(r'%s\s*\(' % kw, st)
    if not m:
        return None
    i = m.end() - 1
    d = 0
    for j in range(i, len(st)):
        if st[j] == '(':
            d += 1
        elif st[j] == ')':
            d -= 1
            if d == 0:
                head = st[i + 1:j]
                rest = st[j + 1:].strip()
                return head, rest
    raise Unconvertible('unbalanced parentheses')


def block_of(rest):
    rest = rest.strip()
    if rest.startswith('{'):
        end = match_brace(rest, 0)
        return rest[1:end], rest[end + 1:].strip()
    # single statement without braces
    parts = split_statements(rest)
    return parts[0] if parts else '', ''


def conv_stmt(st, ind):
    pad = '\t' * ind
    if not st:
        return []
    if re.match(r'(switch|try|do)\b', st):
        raise Unconvertible('switch / try / do-while')
    r = head_and_block(st, 'if')
    if r:
        cond, rest = r
        lines, first = [], True
        while True:
            body, rest = block_of(rest)
            lines.append('%s%s %s then' % (pad, 'if' if first else 'elseif', conv_expr(cond)))
            lines += conv_block(body, ind + 1)
            first = False
            if rest.startswith('else'):
                rest = rest[4:].strip()
                r2 = head_and_block(rest, 'if')
                if r2:
                    cond, rest = r2
                    continue
                body, rest = block_of(rest)
                lines.append(pad + 'else')
                lines += conv_block(body, ind + 1)
            break
        lines.append(pad + 'end')
        return lines
    r = head_and_block(st, 'for')
    if r:
        head, rest = r
        body, _ = block_of(rest)
        m = re.match(r'\s*(\w+)\s+in\s+(.+?)\.\.\.(.+)$', head)
        if m:
            v, a, b = m.groups()
            lines = ['%sfor %s = %s, %s do' % (pad, v, conv_expr(a), conv_expr('(%s) - 1' % b))]
        else:
            m = re.match(r'\s*(\w+)\s+in\s+(.+)$', head)
            if not m:
                raise Unconvertible('for-loop form')
            lines = ['%sfor _, %s in ipairs(%s) do' % (pad, m.group(1), conv_expr(m.group(2)))]
        lines += conv_block(body, ind + 1)
        return lines + [pad + 'end']
    r = head_and_block(st, 'while')
    if r:
        cond, rest = r
        body, _ = block_of(rest)
        return ['%swhile %s do' % (pad, conv_expr(cond))] + conv_block(body, ind + 1) + [pad + 'end']
    if st.startswith('{'):
        end = match_brace(st, 0)
        return [pad + 'do'] + conv_block(st[1:end], ind + 1) + [pad + 'end']
    if st.startswith('return'):
        v = st[6:].strip()
        return [pad + ('return ' + conv_expr(v) if v else 'do return end')]
    if st in ('break', 'continue'):
        if st == 'continue':
            raise Unconvertible('continue (no Lua equivalent without goto)')
        return [pad + 'break']
    m = re.match(r'(?:final|var)\s+(\w+)\s*(?::\s*[\w.<>]+)?\s*(?:=\s*(.*))?$', st, re.S)
    if m:
        return ['%slocal %s%s' % (pad, m.group(1), (' = ' + conv_expr(m.group(2))) if m.group(2) else '')]
    m = re.match(r'(.+?)\s*([+\-*/])=\s*(.+)$', st, re.S)
    if m and not re.search(r'[=<>!]=', m.group(1)):
        t = conv_expr(m.group(1))
        op = '..' if m.group(2) == '+' and re.search(r'\x27|"', m.group(3)) else m.group(2)
        return ['%s%s = %s %s %s' % (pad, t, t, op, conv_expr(m.group(3)))]
    m = re.match(r'(\w[\w.\[\]]*)\s*(\+\+|--)$', st)
    if m:
        return ['%s%s = %s %s 1' % (pad, m.group(1), m.group(1), m.group(2)[0])]
    m = re.match(r'([^=<>!]+?)\s=\s(?!=)(.+)$', st, re.S) or re.match(r'([\w.\[\]()\'"]+)\s*=(?!=)\s*(.+)$', st, re.S)
    if m:
        return ['%s%s = %s' % (pad, conv_expr(m.group(1)), conv_expr(m.group(2)))]
    return [pad + conv_expr(st)]


# ----------------------------------------------------------------------------- balance check (guards AI / odd output)
def lua_balanced(code):
    code = re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|--[^\n]*", '', code)
    opens = len(re.findall(r'\b(function|if|for|while|do)\b', code)) - len(re.findall(r'\bfor\b[^\n]*\bdo\b|\bwhile\b[^\n]*\bdo\b', code))
    return opens == len(re.findall(r'\bend\b', code)) and code.count('(') == code.count(')') and code.count('{') == code.count('}')


# ----------------------------------------------------------------------------- file level
class Result:
    def __init__(self):
        self.lua, self.failed = [], []     # failed: (function, reason, haxe source)
        self.ok = 0


def convert_source(src, kind='script', name=''):
    """-> (lua_text, Result)"""
    R = Result()
    lines = ['-- PortYou Studio: converted from %s (%s)' % (name or 'Haxe', kind)]
    members = split_members(src)
    if not members:
        R.failed.append(('<file>', 'no functions or variables recognised', src.strip()[:4000]))
    for mem in members:
        if mem[0] == 'var':
            try:
                lines += conv_stmt(mem[1].strip().rstrip(';').replace('public ', '').replace('static ', '').replace('private ', ''), 0)
            except Unconvertible as ex:
                R.failed.append(('<variable>', str(ex), mem[1]))
            continue
        _, fname, args, body = mem
        if fname == 'new':
            continue
        lname = CALLBACKS.get(fname, fname)
        params = [re.sub(r'\s*[:=].*$', '', a).strip() for a in args.split(',') if a.strip()]
        try:
            code = conv_block(body)
            lua = '\n'.join(['function %s(%s)' % (lname, ', '.join(params))] + code + ['end'])
            if not lua_balanced(lua):
                raise Unconvertible('result did not pass the syntax balance check')
            lines.append(lua); R.ok += 1
        except Unconvertible as ex:
            fixed = None
            if AI.URL:
                cand = AI.haxe_to_lua('function %s(%s) {%s}' % (fname, args, body), kind)
                if cand and lua_balanced(cand):
                    fixed = cand
            if fixed:
                lines.append('-- (translated with the local AI, please test)\n' + fixed); R.ok += 1
            else:
                R.failed.append((fname, str(ex), 'function %s(%s) {%s}' % (fname, args, body)))
                lines.append('-- PortYou: function "%s" was NOT converted (%s)' % (fname, ex))
    return '\n'.join(lines) + '\n', R


def event_wrapper(kind, lua_text):
    """V-Slice SongEvent.handleEvent(data) -> Psych custom event: onEvent(name, v1, v2); data.value = parsed 'k=v;k=v'."""
    lua_text = re.sub(r'\bfunction handleEvent\(', 'local function handleEvent(', lua_text)
    pre = ('local function _parse(s) local t = {} for kv in string.gmatch(s or "", "[^;]+") do local k, v = string.match(kv, "^([^=]+)=(.*)$") '
           'if k then t[k] = tonumber(v) or (v == "true" and true) or (v == "false" and false) or v end end return t end\n')
    post = '\nfunction onEvent(name, v1, v2)\n\tif name == %r then pcall(handleEvent, {value = _parse(v1), event = name}) end\nend\n' % kind
    return pre + lua_text + post


def convert_many(files, out_dir, unconverted_dir, langs=None):
    """files: list of (path, kind, event_name|None).  Writes lua into out_dir (mod root); anything that could not be converted
    is moved OUT of the mod into unconverted_dir together with a multilingual report.  Returns (n_ok, failures)."""
    failures, ok_files = [], 0
    for path, kind, ev in files:
        try:
            src = open(path, encoding='utf-8', errors='ignore').read()
            lua, R = convert_source(src, kind, os.path.basename(path))
        except Unconvertible as ex:
            failures.append((os.path.basename(path), '<file>', str(ex), '')); continue
        base = os.path.splitext(os.path.basename(path))[0]
        if R.ok:
            if kind == 'event':
                lua = event_wrapper(ev or base, lua)
                dest = os.path.join(out_dir, 'custom_events', (ev or base) + '.lua')
            elif kind == 'stage':
                dest = os.path.join(out_dir, 'stages', base + '.lua')
                if os.path.isfile(dest):   # keep the generated prop code, append the converted callbacks
                    lua = open(dest, encoding='utf-8').read() + '\n' + lua
            else:
                dest = os.path.join(out_dir, 'scripts', 'hx_' + base + '.lua')
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            open(dest, 'w', encoding='utf-8').write(lua)
            ok_files += 1
        for fn, why, code in R.failed:
            failures.append((os.path.basename(path), fn, why, code))
    if failures:
        write_unconverted(failures, files, unconverted_dir, langs)
    return ok_files, failures


REPORT_HEAD = {
    'ar': 'ماقدرت أحول هذا — أجزاء من أكواد الهاكس لم يستطع المحوّل تحويلها إلى لوا. تم فصلها عن المود وهذه قائمتها:',
    'en': "Could not convert this — parts of the Haxe code could not be turned into Lua. They were separated from the mod; here is the list:",
    'pt': 'Não consegui converter isto — partes do código Haxe não puderam virar Lua. Foram separadas do mod; segue a lista:',
    'ja': 'これは変換できませんでした — Haxeコードの一部をLuaに変換できませんでした。MODから分離済みです。一覧:',
}


def write_unconverted(failures, files, d, langs=None):
    os.makedirs(d, exist_ok=True)
    langs = langs or ['ar', 'en', 'pt', 'ja']
    txt = []
    for l in langs:
        txt.append('=' * 60 + '\n[%s] %s\n' % (l, REPORT_HEAD[l]))
    txt.append('=' * 60)
    for f, fn, why, code in failures:
        txt.append('\n* %s :: %s\n    reason: %s' % (f, fn, why))
    open(os.path.join(d, 'ماقدرت_احول_ذا_COULD_NOT_CONVERT.txt'), 'w', encoding='utf-8').write('\n'.join(txt) + '\n')
    raw = os.path.join(d, 'haxe_sources')
    os.makedirs(raw, exist_ok=True)
    for f, fn, why, code in failures:
        if code:
            open(os.path.join(raw, '%s__%s.hx' % (os.path.splitext(f)[0], re.sub(r'\W', '_', fn))), 'w', encoding='utf-8').write(code)
