"""Optional LOCAL AI helper (off unless PORTYOU_LLM_URL is set, e.g. a llama.cpp / Ollama OpenAI-compatible server on the phone/PC).
Everything works without it: the built-in heuristics (difflib / rule tables) run first and the AI is only asked when they fail."""
import json, os, urllib.request

URL = os.environ.get('PORTYOU_LLM_URL', '').rstrip('/')
MODEL = os.environ.get('PORTYOU_LLM_MODEL', 'local')


def ask(prompt, system='You are a precise assistant for porting Friday Night Funkin mods. Answer with the requested format only.', timeout=60):
    if not URL:
        return None
    body = json.dumps({'model': MODEL, 'temperature': 0, 'messages': [{'role': 'system', 'content': system}, {'role': 'user', 'content': prompt}]}).encode()
    try:
        req = urllib.request.Request(URL + '/v1/chat/completions', body, {'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)['choices'][0]['message']['content']
    except Exception:
        return None


def label_hint(wanted, labels):
    """Which Animate label is the animation called `wanted`? returns one of labels or None."""
    out = ask('Animation wanted: "%s". Available labels: %s. Reply with exactly one label from the list, or NONE.' % (wanted, json.dumps(labels)))
    if out:
        out = out.strip().strip('"\'')
        if out in labels:
            return out
    return None


def haxe_to_lua(code, kind):
    """Ask the model to translate one Haxe function to Psych Lua. The result is validated by the caller."""
    out = ask('Translate this Haxe (%s) function to Psych Engine 1.0 Lua. Reply with Lua code only, no markdown.\n\n%s' % (kind, code))
    if out:
        out = out.strip()
        if out.startswith('```'):
            out = '\n'.join(l for l in out.splitlines() if not l.startswith('```'))
    return out
